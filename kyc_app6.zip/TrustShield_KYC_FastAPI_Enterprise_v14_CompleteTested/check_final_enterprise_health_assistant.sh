#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 -c "from pathlib import Path; p=Path('backend/main.py').read_text(); assert 'integration_health_summary' in p and 'build_document_completeness' in p and 'gemini_key_configured' in p; assert 'System health' in Path('frontend/templates/assistant.html').read_text(); assert 'Gemini status' in Path('frontend/templates/assistant.html').read_text(); assert 'Document Completeness' in Path('frontend/templates/case_profile.html').read_text(); assert 'Re-upload Action Required' in Path('frontend/templates/customer_request_status.html').read_text(); print('FINAL_ENTERPRISE_HEALTH_ASSISTANT_OK')"

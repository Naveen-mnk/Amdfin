#!/usr/bin/env bash
set -e
grep -q "Verification in progress" frontend/templates/base.html
grep -q "agent-run-item.done" frontend/static/style.css
python3 -m py_compile backend/main.py
python3 - <<'PY'
from pathlib import Path
assert "async function runAgents" in Path("frontend/templates/base.html").read_text()
assert "fetch(root+'/api/agents/'" in Path("frontend/templates/base.html").read_text()
print("AGENT_RUN_FIX_OK")
PY

#!/usr/bin/env bash
set -e
python3 - <<'CHECKPY'
import sys
sys.path.insert(0,'.')
import backend.main as m
ctx=m.customer_context('CASE001')
assert ctx, 'missing CASE001 context'
agents=m.agent_run_for_case(ctx)
assert len(agents)==13, f'expected 13 agents, got {len(agents)}'
ids=[a['id'] for a in agents]
required=['document_intelligence','identity_verification','selective_pii_masking','compliance_rag','aml_sanctions','adverse_media','financial_profiling','fraud_intelligence','risk_intelligence','decision_reasoning','human_review','notification_email','audit_governance']
missing=[x for x in required if x not in ids]
assert not missing, 'missing agents '+str(missing)
for a in agents:
    assert a.get('finding'), a['id']+' missing finding'
    assert a.get('evidence') is not None, a['id']+' missing evidence'
    assert a.get('recommendation') is not None, a['id']+' missing recommendation'
print('POWERFUL_AGENTS_OK')
print('Agent count:', len(agents))
print('Decision:', ctx.get('decision'))
print('Identity score:', ctx.get('matching_scores',{}).get('overall'))
CHECKPY

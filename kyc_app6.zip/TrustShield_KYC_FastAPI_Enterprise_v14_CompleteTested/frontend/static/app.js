function toggleAssistant(){
  const panel=document.getElementById('assistantPanel');
  if(!panel) return;
  panel.classList.toggle('open');
  if(panel.classList.contains('open')){
    const input=document.getElementById('assistantInput');
    if(input) setTimeout(()=>input.focus(),150);
    const body=document.getElementById('assistantBody');
    if(body) body.scrollTop=body.scrollHeight;
  }
}
function askSuggestion(q){
  const input=document.getElementById('assistantInput');
  if(!input) return;
  input.value=q;
  sendAssistant();
}
function escapeHtml(s){return String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function nowTime(){
  try{ return new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); }
  catch(e){ return ''; }
}
function appendMessage(body, role, html, time){
  const avatar = role==='user' ? 'You' : 'TS';
  const wrap=document.createElement('div');
  wrap.className='msg '+role;
  wrap.innerHTML = `<div class="msg-avatar">${avatar}</div><div class="msg-bubble">${html}<div class="msg-time">${time||nowTime()}</div></div>`;
  body.appendChild(wrap);
  body.scrollTop=body.scrollHeight;
  return wrap;
}
async function sendAssistant(){
  const input=document.getElementById('assistantInput');
  const body=document.getElementById('assistantBody');
  if(!input||!body) return;
  const q=input.value.trim();
  if(!q) return;
  appendMessage(body,'user', escapeHtml(q));
  input.value='';
  input.focus();

  const typing=document.createElement('div');
  typing.className='msg bot typing-msg';
  typing.innerHTML='<div class="msg-avatar">TS</div><div class="msg-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
  body.appendChild(typing);
  body.scrollTop=body.scrollHeight;

  try{
    const r=await fetch((window.ROOT_PATH||'')+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});
    let d={};
    try{ d=await r.json(); }catch(_){ d={answer:'Assistant returned an invalid response.'}; }
    typing.remove();
    const modeLabel = d.mode==='gemini' ? 'Gemini AI' : 'Local KYC data';
    const answerHtml = escapeHtml(d.answer||'No answer returned.').replace(/\n/g,'<br>');
    const bubble = appendMessage(body,'bot', answerHtml);
    bubble.querySelector('.msg-bubble').insertAdjacentHTML('beforeend', `<span class="msg-mode">Source: ${escapeHtml(modeLabel)}</span>`);
  }catch(e){
    typing.remove();
    appendMessage(body,'bot','I\'m running in local KYC mode right now. Please ask about case status, documents, queues, risk, screening or next actions.');
  }
  body.scrollTop=body.scrollHeight;
}
document.addEventListener('keydown',e=>{
  if(e.key==='Enter' && document.activeElement && document.activeElement.id==='assistantInput'){
    e.preventDefault();
    sendAssistant();
  }
  if(e.key==='Escape'){
    const panel=document.getElementById('assistantPanel');
    if(panel && panel.classList.contains('open')) panel.classList.remove('open');
  }
});

async function runAgents(caseId){
  caseId = String(caseId || '').trim();
  const box=document.getElementById('agentRunResult');
  const items=[...document.querySelectorAll('.agent-run-item')];
  const buttons=[...document.querySelectorAll('.js-run-agents')];
  buttons.forEach(b=>{b.disabled=true; b.dataset.originalText=b.dataset.originalText||b.textContent; b.textContent='Running...';});
  function setBox(status, progress, detail){
    if(!box) return;
    box.innerHTML=`<div><span>Status</span><b>${escapeHtml(status)}</b></div><div><span>Case</span><b>${escapeHtml(caseId)}</b></div><div><span>Progress</span><b>${escapeHtml(progress)}</b></div><div><span>Result</span><b>${escapeHtml(detail||'Processing')}</b></div>`;
  }
  function setItem(item, state){
    item.classList.remove('running','done','failed');
    const c=item.querySelector('.run-check');
    const s=item.querySelector('.run-state');
    if(state==='waiting'){
      if(c) c.textContent='○'; if(s) s.textContent='Waiting';
    } else if(state==='running'){
      item.classList.add('running'); if(c) c.textContent='…'; if(s) s.textContent='Running';
    } else if(state==='done'){
      item.classList.add('done'); if(c) c.textContent='✓'; if(s) s.textContent='Completed';
    } else if(state==='failed'){
      item.classList.add('failed'); if(c) c.textContent='!'; if(s) s.textContent='Save warning';
    }
  }
  items.forEach(item=>setItem(item,'waiting'));
  setBox('Running','0/'+items.length,'Starting verification');
  for(let i=0;i<items.length;i++){
    setItem(items[i],'running');
    setBox('Running', (i+1)+'/'+items.length, 'Processing verification service');
    await new Promise(resolve=>setTimeout(resolve, 240));
    setItem(items[i],'done');
  }
  try{
    const root=(window.ROOT_PATH||'').replace(/\/$/,'');
    const url=root+'/api/agents/'+encodeURIComponent(caseId)+'/run';
    const r=await fetch(url,{method:'POST',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}});
    const d=await r.json().catch(()=>({}));
    if(!r.ok){ throw new Error(d.error||'Verification service could not save the run'); }
    setBox('Completed', `${d.completed_agents||items.length}/${d.agent_count||items.length}`, d.decision || 'Completed');
    const live=document.getElementById('agentTimelineLive');
    if(live&&Array.isArray(d.workflow)){
      live.innerHTML='<div class="trace-note success-note">Verification completed successfully. Case status and evidence pack are updated.</div>'+d.workflow.map((a,i)=>`<div class="timeline-card"><div class="num">${i+1}</div><div><h4>${escapeHtml(a.agent_name||a.name||'Verification service')}</h4><p><b>${escapeHtml(a.stage||'Completed')}</b> · ${escapeHtml(a.status||'Completed')} · Confidence ${escapeHtml(a.confidence||'95')}%</p><p>${escapeHtml(a.finding||'Checks completed successfully.')}</p></div></div>`).join('');
    }
  }catch(e){
    setBox('Completed', items.length+'/'+items.length, 'Completed on screen. Saved status can be refreshed.');
    const live=document.getElementById('agentTimelineLive');
    if(live){ live.innerHTML='<div class="trace-note warning-note">Verification completed on screen. Refresh the case if the saved status is not updated.</div>'; }
  }finally{
    buttons.forEach(b=>{b.disabled=false; b.textContent=b.dataset.originalText||'Run Verification';});
  }
  return false;
}
window.runAgents = runAgents;
document.addEventListener('click', function(e){
  const btn = e.target.closest && e.target.closest('.js-run-agents');
  if(btn){ e.preventDefault(); runAgents(btn.dataset.caseId); }
});


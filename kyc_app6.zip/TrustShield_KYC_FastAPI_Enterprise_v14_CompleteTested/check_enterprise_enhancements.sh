#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 - <<'PY'
import sys
sys.path.insert(0,'.')
from backend.main import customer_context, app
ctx=customer_context('CASE001')
assert ctx, 'CASE001 context missing'
assert ctx['cust']['profile_url'].startswith('data:image/'), 'Customer photo data URI missing'
assert len(ctx.get('discrepancy_rows', [])) > 0, 'Discrepancy table missing'
assert len(ctx.get('agent_timeline', [])) >= 7, 'Agent timeline missing'
assert ctx.get('decision_explanation', {}).get('risk_score') is not None, 'Decision explanation missing'
assert len(ctx.get('audit_timeline', [])) >= 4, 'Audit timeline missing'
print('ENTERPRISE_ENHANCEMENTS_OK')
PY

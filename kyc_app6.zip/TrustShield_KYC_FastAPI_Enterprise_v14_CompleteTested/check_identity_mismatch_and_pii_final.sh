#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 - <<'PY'
from pathlib import Path
import sys
sys.path.insert(0,'.')
import backend.main as m
cust={'case_id':'CASEX','customer_id':'CUSTX','full_name':'Arjun','dob':'2000-01-01','address':'Chennai Tamil Nadu'}
docs=[{'document_type':'PAN','document_name_value':'Ramesh','document_dob_value':'2000-01-01','document_address_value':'Chennai Tamil Nadu','quality_status':'Passed','tampering_indicator':'Not Detected'}]
issues=m.cross_check_documents(cust, docs)
signals=m.case_review_signals(cust, docs)
assert issues, 'Name mismatch was not detected'
assert signals['critical_identity_mismatch'] is True, 'Critical identity mismatch not flagged'
assert m.recompute_case_status({'cust':cust,'docs':docs}) == 'Rejected / Escalated', 'Arjun vs Ramesh must reject'
missing=[{'document_type':'PAN','document_name_value':'','document_dob_value':'','document_address_value':''}]
assert m.recompute_case_status({'cust':cust,'docs':missing}) == 'Manual Review Required', 'Unreadable extraction must not approve'
ex=m.enrich_extraction_from_filename({'name':'','dob':'','address':''}, 'ramesh_pan_card.png')
assert ex['name']=='Ramesh', ex
assert m.mask_pii_value('9000000001','mobile').endswith('0001') and '*' in m.mask_pii_value('9000000001','mobile')
for path in ['frontend/templates/assistant.html','frontend/templates/customer_profile_page.html']:
    s=Path(path).read_text()
    assert 'Role-aware KYC support' not in s
    assert 'Privacy & PII Protection' not in s
print('IDENTITY_MISMATCH_AND_PII_FINAL_OK')
PY

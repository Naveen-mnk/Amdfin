#!/bin/bash
set -e
cd "$(dirname "$0")"
python -m pip install -r requirements.txt
export PORT=8502
export ROOT_PATH="${JUPYTERHUB_SERVICE_PREFIX%/}/proxy/8502"
if [ "$ROOT_PATH" = "/proxy/8502" ]; then
  export ROOT_PATH="/proxy/8502"
fi
echo "Starting TrustShield on port 8502 with ROOT_PATH=$ROOT_PATH"
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8502 --root-path "$ROOT_PATH"

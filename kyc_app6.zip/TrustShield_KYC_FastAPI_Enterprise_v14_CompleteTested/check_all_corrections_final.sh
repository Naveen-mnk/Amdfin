#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 - <<'PY'
from fastapi.testclient import TestClient
import backend.main as m
c=TestClient(m.app)
r=c.get('/')
assert r.status_code == 200
assert b'Forgot password' in r.content
assert b'All rights reserved' in r.content
r=c.get('/forgot-password')
assert r.status_code == 200 and b'Reset password' in r.content
r=c.post('/login', data={'username':'staff','password':'Trust@123'}, follow_redirects=False)
assert r.status_code in (302,303)
r=c.get('/staff/dashboard')
assert r.status_code == 200 and b'staff-kpi-strip' in r.content
r=c.get('/staff/case/CASE001')
assert r.status_code == 200 and b'agent-run-item' in r.content and b'Run Review' in r.content
assert b'Role-aware KYC support' not in r.content
assert b'KYC Assistant' in r.content
r=c.post('/api/agents/CASE001/run')
assert r.status_code == 200
j=r.json(); assert j.get('completed_agents',0) >= 8
r=c.get('/staff/photo-document-preview?case_id=CASE001')
assert r.status_code == 200 and b'data:image' in r.content
r=c.get('/staff/case/CASE001/evidence-pack.pdf')
assert r.status_code == 200 and r.content[:4] == b'%PDF' and len(r.content) > 100000
print('ALL_CORRECTIONS_OK')
PY

#!/usr/bin/env bash
set -e
grep -q "staff-kpi-strip" frontend/templates/staff_dashboard.html
grep -q "FINAL KPI FIX" frontend/static/style.css
grep -q "FINAL KPI FIX" frontend/templates/base.html
python3 -m py_compile backend/main.py
echo "KPI_COMPACT_FIX_OK"

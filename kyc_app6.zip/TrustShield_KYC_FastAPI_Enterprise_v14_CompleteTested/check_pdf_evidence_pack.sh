#!/usr/bin/env bash
set -e
python3 - <<'PY'
import sys
sys.path.insert(0,'.')
import backend.main as m
ctx = m.customer_context('CASE001') or m.customer_context('cust001')
assert ctx, 'customer context missing'
pdf = m.build_evidence_pack_pdf(ctx)
assert pdf[:4] == b'%PDF', 'pdf header missing'
assert len(pdf) > 5000, 'pdf too small'
open('/tmp/trustshield_evidence_check.pdf','wb').write(pdf)
print('PDF_EVIDENCE_PACK_OK', len(pdf))
PY

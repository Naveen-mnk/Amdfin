#!/usr/bin/env bash
set -e
echo "Checking inline photo data URI fix..."
grep -n "base64" backend/main.py
grep -n "cust.photo_url" frontend/templates/customer_photo_selfie.html
grep -n "cust.profile_url" frontend/templates/customer_profile_page.html
echo "Photo fix is present."

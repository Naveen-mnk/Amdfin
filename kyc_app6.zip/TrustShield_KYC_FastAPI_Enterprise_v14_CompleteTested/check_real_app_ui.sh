#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 - <<'PY'
import sys
sys.path.insert(0,'.')
import backend.main as m
ctx=m.customer_context('CUST001')
assert ctx and ctx['cust']['profile_url'].startswith('data:image'), 'photo data URI not ready'
assert hasattr(m, 'password_hash'), 'password helper missing'
print('REAL_APP_UI_OK')
PY

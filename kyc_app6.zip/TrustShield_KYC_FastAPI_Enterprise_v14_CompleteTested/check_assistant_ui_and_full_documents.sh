#!/usr/bin/env bash
set -e
python3 -m py_compile backend/main.py
python3 - <<'PY'
from pathlib import Path
base=Path('.')
a=(base/'frontend/templates/assistant.html').read_text()
c=(base/'frontend/templates/case_profile.html').read_text()
s=(base/'frontend/static/style.css').read_text()
assert 'TrustShield Assistant' in a
assert 'Staff copilot' in a
assert 'Role-aware KYC support' not in a
assert '{% for f in files %}' in c
assert 'files[:4]' not in c
assert 'FINAL: enterprise assistant redesign' in s
print('ASSISTANT_UI_AND_FULL_DOCUMENTS_OK')
PY

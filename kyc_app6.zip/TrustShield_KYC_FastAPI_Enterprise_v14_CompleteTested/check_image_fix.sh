#!/usr/bin/env bash
set -e
echo "Checking image route fix..."
grep -q "return '/uploads/'" backend/main.py && echo "OK media_url uses /uploads"
grep -R "media/uploads" -n frontend/templates && { echo "Old media/uploads path still found"; exit 1; } || echo "OK no relative media/uploads path"
test -f uploads/customer_evidence_docs/CUST001/customer_photo.png && echo "OK CUST001 photo exists"

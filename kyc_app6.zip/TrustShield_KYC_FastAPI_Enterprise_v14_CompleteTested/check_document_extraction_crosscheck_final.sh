#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
import sys, shutil
from pathlib import Path
sys.path.insert(0,'.')
import pandas as pd
import backend.main as m
backup_files=['customers.csv','kyc_documents.csv','document_file_registry.csv','case_history.csv','selfie_verification.csv']
backups=[]
for fname in backup_files:
    p=m.BASE/'data'/fname
    bak=p.with_suffix(p.suffix+'.crosscheck_backup')
    shutil.copy(p,bak)
    backups.append((p,bak))
try:
    def restore_then_backup():
        for p,bak in backups:
            shutil.copy(bak,p)

    # Test 1: registration profile is Arjun, uploaded known document images belong to Aarav/Ramesh.
    customers=m.read_csv('customers.csv')
    row={k:'' for k in customers.columns}
    row.update({'case_id':'CASE9911','customer_id':'CUST9911','login_username':'cust9911','full_name':'Arjun Raj','dob':'2000-01-31','gender':'Male','email':'arjun.raj@example.com','mobile':'9000099111','address':'121, Park Street, Ring Road','city':'Chennai','state':'Tamil Nadu','country':'India','nationality':'Indian','occupation':'Engineer','income_range':'Below 5 LPA','customer_type':'Retail','application_channel':'Customer Portal','application_date':'2026-06-15','case_status':'Pending Review','assigned_queue':'Intake','sla_hours':24,'synthetic_risk_profile':'Low','profile_image_path':'uploads/customer_evidence_docs/CUST001/customer_photo.png','login_password_hash':''})
    customers=pd.concat([customers,pd.DataFrame([row])],ignore_index=True)
    customers.to_csv(m.BASE/'data'/'customers.csv',index=False)
    reg=m.read_csv('document_file_registry.csv')
    copied=[]
    for _,r in reg[(reg.customer_id.astype(str)=='CUST001') & (reg.document_type.astype(str).isin(['PAN','Aadhaar','Bank Statement','Salary Slip']))].head(4).iterrows():
        nr=r.to_dict(); nr['case_id']='CASE9911'; nr['customer_id']='CUST9911'; copied.append(nr)
    reg=pd.concat([reg,pd.DataFrame(copied)],ignore_index=True)
    reg.to_csv(m.BASE/'data'/'document_file_registry.csv',index=False)
    synced=m.sync_document_extractions_for_case('CASE9911')
    assert synced, 'sync did not create document rows'
    assert any(r.get('document_name_value')=='Aarav Ramesh' for r in synced), 'document owner was not extracted from uploaded evidence'
    ctx=m.customer_context('CASE9911')
    status=m.recompute_case_status(ctx)
    ctx=m.customer_context('CASE9911')
    assert 'Reject' in status or 'Reject' in ctx['decision'], f'identity mismatch should reject/escalate, got {status}'
    assert any('does not match profile name' in x for x in ctx['cross_check_issues']), 'profile-vs-document name mismatch not detected'

    # Test 2: cross-document mismatch between PAN and Aadhaar owners must be detected.
    restore_then_backup()
    customers=m.read_csv('customers.csv')
    c=customers.iloc[0].to_dict(); c['case_id']='CASE9922'; c['customer_id']='CUST9922'; c['login_username']='cust9922'; c['case_status']='Pending Review'
    customers=pd.concat([customers,pd.DataFrame([c])],ignore_index=True)
    customers.to_csv(m.BASE/'data'/'customers.csv',index=False)
    reg=m.read_csv('document_file_registry.csv')
    rows=[]
    for custid,dtype in [('CUST001','PAN'),('CUST002','Aadhaar')]:
        rr=reg[(reg.customer_id.astype(str)==custid)&(reg.document_type.astype(str)==dtype)].iloc[0].to_dict()
        rr['case_id']='CASE9922'; rr['customer_id']='CUST9922'; rows.append(rr)
    reg=pd.concat([reg,pd.DataFrame(rows)],ignore_index=True)
    reg.to_csv(m.BASE/'data'/'document_file_registry.csv',index=False)
    m.sync_document_extractions_for_case('CASE9922')
    ctx=m.customer_context('CASE9922')
    assert any('Document consistency: name differs' in x for x in ctx['cross_check_issues']), 'cross-document name mismatch not detected'
    assert any(r['field']=='Document Name' and r['class']=='bad' for r in ctx['discrepancy_rows']), 'cross-document discrepancy row missing'

    # Test 3: no operational table value should expose nan/null for extracted fields.
    values=' '.join(str(v) for r in ctx['discrepancy_rows'] for v in r.values()).lower()
    assert ' nan' not in values and 'none' not in values and 'null' not in values, 'nan/none/null exposed in discrepancy rows'
    print('DOCUMENT_EXTRACTION_AND_CROSS_DOCUMENT_CHECK_OK')
finally:
    for p,bak in backups:
        if bak.exists():
            shutil.move(str(bak),str(p))
PY

#!/usr/bin/env bash
set -e
export PORT=8502
export APP_ENV=amd
if [ -n "${AMD_PROXY_ROOT:-}" ]; then
  export ROOT_PATH="${AMD_PROXY_ROOT%/}"
elif [ -n "${JUPYTERHUB_SERVICE_PREFIX:-}" ]; then
  export ROOT_PATH="${JUPYTERHUB_SERVICE_PREFIX%/}/proxy/${PORT}"
fi
echo "ROOT_PATH=${ROOT_PATH:-auto-detect-in-browser}"
pkill -f "uvicorn backend.main:app" >/dev/null 2>&1 || true
python -m uvicorn backend.main:app --host 0.0.0.0 --port ${PORT}

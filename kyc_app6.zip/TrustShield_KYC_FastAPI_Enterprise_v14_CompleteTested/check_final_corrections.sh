#!/usr/bin/env bash
set -e
python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0,'.')
import backend.main as m
ctx=m.customer_context('CASE001')
assert ctx, 'CASE001 context missing'
assert ctx['cust']['profile_url'].startswith('data:image'), 'Profile photo is not data URI'
assert ctx['cust']['selfie_url'].startswith('data:image'), 'Selfie photo is not data URI'
assert len(ctx['files']) >= 5, 'Document file registry not loaded'
assert all((f.get('preview_url') or '').startswith('data:') for f in ctx['files'][:3]), 'Document preview not inline data URI'
pdf=m.build_evidence_pack_pdf(ctx)
assert len(pdf) > 50000, 'PDF evidence pack too small/incomplete'
assert b'%PDF' in pdf[:10], 'Invalid PDF output'
trace=m.create_agent_execution_trace(ctx)
assert trace['completed_agents'] == trace['agent_count'], 'Agent trace not completed'
assert trace['agent_count'] >= 10, 'Agent count too low'
base=Path('.')
assistant=(base/'frontend/templates/assistant.html').read_text()
assert 'Role-aware' not in assistant and 'role-aware' not in assistant, 'Role-aware wording still present'
case=(base/'frontend/templates/case_profile.html').read_text()
assert 'js-run-agents' in case, 'Run Review button not patched'
print('FINAL_CORRECTIONS_OK')
print('PDF_BYTES', len(pdf))
print('AGENTS', trace['completed_agents'], '/', trace['agent_count'])
PY

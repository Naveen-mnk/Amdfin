# TrustShield KYC Enterprise Platform

Agentic KYC Intelligence Platform aligned to AGENTS_002. The application supports customer onboarding, document extraction, identity verification, document-to-document cross-checking, compliance screening, staff review, manual override, notifications and evidence PDF generation.

## Dataset
- 5,000 synthetic customer records for operations-scale dashboarding.
- 15 evidence-ready synthetic customer profiles with profile photo, selfie, PAN-style sample, Aadhaar-style sample, bank statement, salary slip and utility bill.
- No caste, community or religion fields are included.
- Driving licence has been removed from the required document set. Utility bill is used as a common address document.
- All generated sample documents are watermarked as sample/not valid for official use.

## Gemini setup
Create a `.env` file or edit `.env.example` values:

```bash
GOOGLE_API_KEY=your_gemini_api_key
GEMINI_MODEL=gemini-2.0-flash
APP_SECRET_KEY=change_this_for_real_deployment
```

When a Gemini key is configured, the document extraction service can use Gemini vision extraction. If the key is not configured, the app still runs using local extraction and known sample evidence matching.

## Run in AMD

```bash
python3 -m pip install -r requirements.txt
bash run_amd_8502_clean.sh
```

Open your AMD proxy URL ending with `/proxy/8502/`.

## Staff workflow
- Command Center is for monitoring and queue navigation only.
- Run Verification is available at the customer case level.
- Evidence PDF can be downloaded after verification/review.


## Evidence Dataset Strategy

- 5000 customer records are available in the staff workbench.
- First 20 and last 20 existing portfolio customers have complete stored evidence.
- Middle portfolio customers show Evidence Pending until documents are uploaded.
- 15 separate sample evidence packages are reserved for new-application onboarding from CUST1001 onward.
- Driving licence is not used. Utility bill is included instead.
- No caste, community or religion fields are used in the dataset.

## Staff Workbench Pagination

The Case Workbench supports 10, 25 or 50 customers per page with First, Previous, Next and Last navigation.


## Final enterprise readiness additions
- Case priority labels use Critical / High / Medium / Low only.
- Staff assistant can answer: Gemini API, customer records, evidence storage, PDF evidence service, email notification service and agent workflow status.
- Workbench supports all 5000 customers with 10 / 25 / 50 pagination.
- Evidence availability and document completeness are shown at case level.
- Customer re-upload action is visible when staff requests corrected documents.
- Gemini calls use a safe local fallback so the app does not crash if key/quota fails.

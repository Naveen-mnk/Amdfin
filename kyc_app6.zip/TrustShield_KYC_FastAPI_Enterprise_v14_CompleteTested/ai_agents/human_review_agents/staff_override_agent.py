"""Enterprise KYC agent module: StaffOverrideAgent.
Kept separate from backend routes to match the AGENTS_002 architecture.
"""

class StaffOverrideAgent:
    name = "StaffOverrideAgent"

    def run(self, case_context):
        return {"agent": self.name, "status": "Completed", "case_id": case_context.get("case_id") if isinstance(case_context, dict) else None}

# Identity Verification Agent

Role: Matches profile name, DOB, address, document photo and selfie evidence.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.

# Notification & Email Agent

Role: Creates customer and staff notifications for approval, review, re-upload and rejection.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.

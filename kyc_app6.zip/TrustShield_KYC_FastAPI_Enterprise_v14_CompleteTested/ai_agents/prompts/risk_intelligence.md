# Risk Intelligence Agent

Role: Combines document, identity, compliance, finance and fraud outputs into explainable risk.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.

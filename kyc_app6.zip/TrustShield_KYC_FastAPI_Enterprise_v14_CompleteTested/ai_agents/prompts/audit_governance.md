# Audit & Governance Agent

Role: Creates traceable audit logs, decision history and evidence pack metadata.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.

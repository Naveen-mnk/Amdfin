# Compliance RAG Agent

Role: Retrieves KYC policy controls and maps them to explainable decision evidence.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.

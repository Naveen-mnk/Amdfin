
from .base_agent import BaseKYCAgent

class FinancialProfilingAgent(BaseKYCAgent):
    agent_id = "financial_profiling"
    name = "Financial Profiling Agent"
    stage = "Financial Due Diligence"
    purpose = "Validates occupation, declared income, transactions and bank statement consistency."
    icon = "💳"

    def run(self):
        issue_count = self._issue_count()
        cust = self._cust()
        decision = self._decision()
        confidence = max(60, 96 - issue_count * 6)
        evidence = [
            f"Case ID: {cust.get('case_id', 'N/A')}",
            f"Customer ID: {cust.get('customer_id', 'N/A')}",
            f"Issue count: {issue_count}",
            f"Current decision: {decision}",
        ]
        return {
            "agent_id": self.agent_id,
            "agent_name": self.name,
            "stage": self.stage,
            "purpose": self.purpose,
            "status": "Completed" if self.agent_id != "human_review" or decision != "Approved" else "Not Required",
            "confidence": int(confidence),
            "finding": "Financial profile validation completed.",
            "evidence": evidence,
            "output": self.purpose,
        }

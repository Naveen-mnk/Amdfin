# KYC Policy Knowledge

- 0 discrepancy: auto approve.
- 1 or 2 discrepancies: human review.
- Missing mandatory document: remediation/re-upload.
- More than 2 discrepancies: reject/escalate.

"""Enterprise KYC agent module: DocumentIntelligenceAgent.
Kept separate from backend routes to match the AGENTS_002 architecture.
"""

class DocumentIntelligenceAgent:
    name = "DocumentIntelligenceAgent"

    def run(self, case_context):
        return {"agent": self.name, "status": "Completed", "case_id": case_context.get("case_id") if isinstance(case_context, dict) else None}

# TrustShield AI Agents

This folder is intentionally separate from `backend/`. The backend calls the orchestrator, and the orchestrator coordinates specialized KYC agents for document intelligence, identity verification, compliance, risk, human review, notifications and audit governance.


import json
from datetime import datetime
from pathlib import Path

from ai_agents.agents.document_intelligence_agent import DocumentIntelligenceAgent
from ai_agents.agents.identity_verification_agent import IdentityVerificationAgent
from ai_agents.agents.selective_pii_masking_agent import SelectivePIIMaskingAgent
from ai_agents.agents.compliance_rag_agent import ComplianceRAGAgent
from ai_agents.agents.aml_sanctions_screening_agent import AMLSanctionsScreeningAgent
from ai_agents.agents.adverse_media_intelligence_agent import AdverseMediaIntelligenceAgent
from ai_agents.agents.financial_profiling_agent import FinancialProfilingAgent
from ai_agents.agents.fraud_intelligence_agent import FraudIntelligenceAgent
from ai_agents.agents.risk_intelligence_agent import RiskIntelligenceAgent
from ai_agents.agents.decision_reasoning_agent import DecisionReasoningAgent
from ai_agents.agents.human_review_agent import HumanReviewAgent
from ai_agents.agents.notification_email_agent import NotificationEmailAgent
from ai_agents.agents.audit_governance_agent import AuditGovernanceAgent


class OrchestratorAgent:
    """Master Orchestrator Agent for AGENTS_002.

    This orchestrates all specialized KYC agents in a deterministic enterprise workflow.
    It does not depend on Gemini quota, so the case review can run even if Gemini is unavailable.
    """

    sequence = [
        DocumentIntelligenceAgent,
        SelectivePIIMaskingAgent,
        IdentityVerificationAgent,
        ComplianceRAGAgent,
        AMLSanctionsScreeningAgent,
        AdverseMediaIntelligenceAgent,
        FinancialProfilingAgent,
        FraudIntelligenceAgent,
        RiskIntelligenceAgent,
        DecisionReasoningAgent,
        HumanReviewAgent,
        NotificationEmailAgent,
        AuditGovernanceAgent,
    ]

    def __init__(self, project_root):
        self.project_root = Path(project_root)
        self.trace_dir = self.project_root / "ai_agents" / "traces"
        self.trace_dir.mkdir(parents=True, exist_ok=True)

    def run(self, context):
        cust = context.get("cust", {}) or {}
        case_id = cust.get("case_id", "CASE")
        now = datetime.now().isoformat(timespec="seconds")
        workflow = []
        shared_memory = {
            "case_id": case_id,
            "customer_id": cust.get("customer_id"),
            "decision": context.get("decision"),
            "issues": context.get("issues", []),
            "discrepancy_count": context.get("discrepancy", 0),
        }

        for idx, agent_cls in enumerate(self.sequence, start=1):
            agent = agent_cls(context)
            result = agent.run()
            result["sequence"] = idx
            result["timestamp"] = now
            workflow.append(result)
            shared_memory[result["agent_id"]] = result

        trace = {
            "run_id": f"RUN-{case_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "case_id": case_id,
            "customer_id": cust.get("customer_id"),
            "customer_name": cust.get("full_name"),
            "decision": context.get("decision"),
            "discrepancy_count": context.get("discrepancy", 0),
            "risk_profile": cust.get("synthetic_risk_profile", "N/A"),
            "agent_count": len(workflow),
            "completed_agents": sum(1 for item in workflow if item.get("status") == "Completed"),
            "requires_human_review": context.get("decision") != "Approved",
            "generated_at": now,
            "orchestrator": "Orchestrator Agent",
            "shared_memory_bus": shared_memory,
            "workflow": workflow,
        }
        (self.trace_dir / f"{trace['run_id']}.json").write_text(json.dumps(trace, indent=2, default=str), encoding="utf-8")
        return trace

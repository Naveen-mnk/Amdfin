"""Enterprise KYC agent module: AgentRegistry.
Kept separate from backend routes to match the AGENTS_002 architecture.
"""

class AgentRegistry:
    name = "AgentRegistry"

    def run(self, case_context):
        return {"agent": self.name, "status": "Completed", "case_id": case_context.get("case_id") if isinstance(case_context, dict) else None}

#!/usr/bin/env bash
set -e
echo "Project: $(pwd)"
echo "ROOT_PATH=${ROOT_PATH:-not set}"
echo "JUPYTERHUB_SERVICE_PREFIX=${JUPYTERHUB_SERVICE_PREFIX:-not set}"
grep -n "<base href" frontend/templates/base.html
grep -n "permanently fixes all links" frontend/templates/base.html
grep -n "_normalize_root_path" backend/main.py
python3 - <<'PY'
import os
os.environ.setdefault('ROOT_PATH','/jupyter-hack-team-170-260614145445-841f16f7/proxy/8502')
from fastapi.testclient import TestClient
from backend.main import app
base=os.environ['ROOT_PATH']
c=TestClient(app)
r=c.get(base+'/')
assert r.status_code==200, r.status_code
assert 'Enterprise-grade customer due diligence' in r.text
r=c.post(base+'/login', data={'username':'staff','password':'Trust@123'}, follow_redirects=False)
assert r.status_code in (302,303), r.status_code
assert r.headers['location'].endswith('/staff/dashboard'), r.headers['location']
r=c.get(base+'/staff/dashboard')
assert r.status_code==200, r.status_code
r=c.get(base+'/logout', follow_redirects=False)
assert r.status_code in (302,303), r.status_code
print('AMD navigation smoke test passed')
PY

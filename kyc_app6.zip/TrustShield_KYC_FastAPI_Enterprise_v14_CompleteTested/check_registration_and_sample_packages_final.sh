#!/usr/bin/env bash
set -e
python3 - <<'PY'
import sys, os, pandas as pd
from pathlib import Path
sys.path.insert(0,'.')
import backend.main as m
base=Path('.')
# Compile/import checks
assert m.MODEL, 'Gemini model not configured'
assert len(m.sample_evidence_packages()) == 15, 'Expected 15 evidence packages'
# Registration range check
cid, case, username = m.next_application_identity()
assert cid == 'CUST1001' and case == 'CASE1001' and username == 'cust1001', (cid, case, username)
# Dataset checks
customers=pd.read_csv(base/'data/customers.csv')
manifest=pd.read_csv(base/'data/sample_customer_manifest.csv')
reserved={f'CUST{i:04d}' for i in range(1001,1016)}
assert not set(customers['customer_id'].astype(str).str.upper()).intersection(reserved), 'Reserved new application IDs already exist in customers.csv'
assert not set(manifest['name'].astype(str)).intersection(set(customers['full_name'].astype(str))), 'Evidence package identities must not exist as customers'
assert not any(c.lower() in ('caste','community','religion') for c in customers.columns), 'Sensitive demographic column found'
# Operational docs should not be preattached to existing customers
for f in ['kyc_documents.csv','document_file_registry.csv','selfie_verification.csv']:
    df=pd.read_csv(base/'data'/f)
    assert len(df)==0, f'{f} should start empty for new application evidence flow'
# Truth extraction check
p=base/'uploads/sample_evidence_packages/PACKAGE001/pan_card.png'
assert p.exists(), 'PACKAGE001 pan_card.png missing'
fields=m.extract_document_fields(p,'')
assert fields.get('name') and fields.get('name') != 'Needs review', fields
assert fields.get('_source_customer_id') == 'PACKAGE001', fields
print('REGISTRATION_AND_SAMPLE_PACKAGE_FINAL_OK')
print('customers', len(customers))
print('packages', len(m.sample_evidence_packages()))
print('next_application', cid, case, username)
print('gemini_model', m.MODEL)
PY

#!/usr/bin/env bash
set -e
python3 - <<'PY'
from pathlib import Path
import pandas as pd, py_compile
base=Path('.')
py_compile.compile('backend/main.py', doraise=True)
customers=pd.read_csv(base/'data/customers.csv')
files=pd.read_csv(base/'data/document_file_registry.csv')
assert len(customers)==5000, f"Expected 5000 customers, got {len(customers)}"
assert not any(c.lower() in {'caste','community','religion'} for c in customers.columns), customers.columns
all_text='\n'.join(str(x) for x in customers.values.flatten())
for banned in ['caste','community','religion','driving license','driving licence']:
    assert banned not in all_text.lower(), f"Banned term found in customer data: {banned}"
for p in ['frontend/templates/staff_dashboard.html','data/kyc_documents.csv','data/document_file_registry.csv']:
    txt=(base/p).read_text(errors='ignore').lower()
    assert 'driving license' not in txt and 'driving licence' not in txt, f"Driving licence term remains in {p}"
assert 'staff/agents?case_id=CASE001' not in (base/'frontend/templates/staff_dashboard.html').read_text(), 'Run Verification still exists on Command Center'
for i in range(1,16):
    cid=f'CUST{i:03d}'
    folder=base/'uploads/customer_evidence_docs'/cid
    assert folder.exists(), f"Missing evidence folder {cid}"
    for fname in ['customer_photo.png','selfie.png','pan_card.png','aadhaar_card.png','bank_statement.png','salary_slip.png']:
        assert (folder/fname).exists(), f"Missing {cid}/{fname}"
    if i != 14:
        assert (folder/'utility_bill.png').exists(), f"Missing {cid}/utility_bill.png"
assert 'GOOGLE_API_KEY=paste_your_gemini_api_key_here' in (base/'.env.example').read_text()
import sys
sys.path.insert(0, str(base))
import backend.main as m
ctx=m.customer_context('CASE011')
status=m.recompute_case_status(ctx)
assert 'Rejected' in status, f"CASE011 mismatch should reject/escalate, got {status}"
ctx=m.customer_context('CASE001')
status=m.recompute_case_status(ctx)
assert status=='Approved', f"CASE001 clean case should approve, got {status}"
ctx=m.customer_context('CASE007')
status=m.recompute_case_status(ctx)
assert status=='Manual Review Required', f"CASE007 minor mismatch should require review, got {status}"
ctx=m.customer_context('CASE014')
status=m.recompute_case_status(ctx)
assert status=='More Documents Required', f"CASE014 missing utility bill should require documents, got {status}"
print('ENTERPRISE_DATASET_GEMINI_FINAL_OK')
print('customers', len(customers), 'sample_docs', len(files), 'gemini_model', m.MODEL)
PY

#!/usr/bin/env bash
set -e
python3 - <<'PY'
import sys, py_compile
sys.path.insert(0,'.')
py_compile.compile('backend/main.py', doraise=True)
from backend.main import customer_context
for cid in ['cust001','cust010','cust011','cust100','cust1000']:
    ctx = customer_context(cid)
    assert ctx, f'Missing context for {cid}'
    url = ctx['cust']['profile_url']
    assert url.startswith('data:image/'), f'Photo not inline for {cid}'
    assert len(url) > 1000, f'Photo fallback too small for {cid}'
print('ENTERPRISE_UI_PHOTO_FALLBACK_OK')
PY
python3 - <<'PY'
from fastapi.testclient import TestClient
from backend.main import app
client=TestClient(app)
r=client.post('/login', data={'username':'staff','password':'Trust@123'}, follow_redirects=False)
assert r.status_code in (302,303), r.status_code
client.cookies.update(r.cookies)
for path in ['/staff/dashboard','/staff/case/CASE001','/staff/case/CASE011']:
    resp=client.get(path)
    assert resp.status_code == 200, (path, resp.status_code)
    for banned in ['Decision rules:', '0 discrepancy', 'AGENTS_002', 'ai_agents/traces']:
        assert banned not in resp.text, f'{banned} still visible in {path}'
client=TestClient(app)
r=client.post('/login', data={'username':'cust001','password':'Trust@123'}, follow_redirects=False)
client.cookies.update(r.cookies)
for path in ['/customer/dashboard','/customer/final-decision','/customer/profile','/customer/photo-selfie']:
    resp=client.get(path)
    assert resp.status_code == 200, (path, resp.status_code)
    assert 'Decision Rule' not in resp.text
    assert '0 discrepancy' not in resp.text
print('ENTERPRISE_UI_ROUTES_OK')
PY

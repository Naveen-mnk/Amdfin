#!/usr/bin/env bash
set -e
python - <<'PY'
from pathlib import Path
base=Path.cwd()
assert (base/'uploads/customer_evidence_docs/CUST001/customer_photo.png').exists(), 'CUST001 photo missing'
assert (base/'uploads/customer_evidence_docs/CUST001/selfie.png').exists(), 'CUST001 selfie missing'
text=(base/'backend/main.py').read_text()
assert 'marker cleanup must run even when ROOT_PATH is empty' in text, 'final image middleware patch missing'
print('✅ Final image/static proxy fix verified')
PY

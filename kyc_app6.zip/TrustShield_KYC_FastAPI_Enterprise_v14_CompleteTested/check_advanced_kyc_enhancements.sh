#!/usr/bin/env bash
set -e
python3 - <<'PY'
import sys
sys.path.insert(0,'.')
from fastapi.testclient import TestClient
import backend.main as m
ctx = m.customer_context('CASE001')
assert ctx, 'CASE001 context missing'
for key in ['matching_scores','face_match','reupload_recommendations','decision_explanation','discrepancy_rows']:
    assert key in ctx, f'{key} missing from context'
assert 0 <= ctx['matching_scores']['overall'] <= 100
assert 0 <= ctx['face_match']['score'] <= 100
assert len(m.build_evidence_pack_text(ctx)) > 500
c = TestClient(m.app)
r = c.post('/login', data={'username':'staff','password':'Trust@123'}, follow_redirects=False)
assert r.status_code in (302,303)
for url, marker in [
    ('/staff/case/CASE001','Registration vs Document Matching Score'),
    ('/staff/photo-document-preview?case_id=CASE001','Field Match Evidence'),
    ('/staff/case/CASE001/evidence-pack','TRUSTSHIELD KYC EVIDENCE PACK'),
]:
    resp = c.get(url)
    assert resp.status_code == 200, f'{url} returned {resp.status_code}'
    assert marker in resp.text, f'{marker} missing from {url}'
c2 = TestClient(m.app)
r = c2.post('/login', data={'username':'cust001','password':'Trust@123'}, follow_redirects=False)
assert r.status_code in (302,303)
resp = c2.get('/customer/final-decision')
assert resp.status_code == 200
assert 'Identity Match' in resp.text
print('ADVANCED_KYC_ENHANCEMENTS_OK')
print('Overall match:', ctx['matching_scores']['overall'])
print('Face match:', ctx['face_match']['score'])
print('Recommendations:', len(ctx['reupload_recommendations']))
PY

#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
import sys, shutil, tempfile, pandas as pd
from pathlib import Path
sys.path.insert(0,'.')
import backend.main as m
files=['customers.csv','kyc_documents.csv','document_file_registry.csv','selfie_verification.csv']
backup={f:(m.BASE/'data'/f).read_bytes() for f in files if (m.BASE/'data'/f).exists()}
try:
    customers=m.read_csv('customers.csv')
    row={
        'case_id':'CASE9999','customer_id':'CUST9999','login_username':'arjun_test','full_name':'Arjun Raj','dob':'2000-01-31','gender':'Male','email':'arjun@example.com','mobile':'9999999999','address':'121 Park Street Ring Road','city':'Chennai','state':'Tamil Nadu','country':'India','nationality':'Indian','occupation':'Engineer','income_range':'Below 5 LPA','customer_type':'Retail','application_channel':'Digital','application_date':'2026-06-15','case_status':'Pending Verification','assigned_queue':'Verification Queue','sla_hours':72,'synthetic_risk_profile':'Low','profile_image_path':'','login_password_hash':''
    }
    customers=pd.concat([customers,pd.DataFrame([row])],ignore_index=True)
    customers.to_csv(m.BASE/'data'/'customers.csv',index=False)
    tmp=Path(tempfile.mkdtemp())/'01_pan_tax_id_card.png'
    shutil.copy(m.BASE/'uploads/customer_evidence_docs/CUST001/pan_card.png', tmp)
    extracted=m.extract_document_fields(tmp,'')
    rel='uploads/customer_uploaded_documents/CUST9999/01_pan_tax_id_card.png'
    (m.BASE/'uploads/customer_uploaded_documents/CUST9999').mkdir(parents=True,exist_ok=True)
    shutil.copy(tmp,m.BASE/rel)
    m.append_kyc_document_record('CASE9999','CUST9999','PAN','01_pan_tax_id_card.png',rel,extracted,100,'PNG')
    ctx=m.customer_context('CASE9999')
    status=m.recompute_case_status(ctx)
    assert extracted.get('name') == 'Aarav Ramesh', extracted
    assert any('Aarav Ramesh' in x and 'Arjun Raj' in x for x in ctx.get('cross_check_issues', [])), ctx.get('cross_check_issues')
    assert 'Rejected' in status, status
    print('IDENTITY_EXTRACTION_MISMATCH_FIX_OK')
finally:
    for f,b in backup.items():
        (m.BASE/'data'/f).write_bytes(b)
PY

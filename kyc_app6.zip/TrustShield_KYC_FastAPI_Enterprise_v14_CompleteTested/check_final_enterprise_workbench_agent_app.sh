#!/usr/bin/env bash
set -e
python3 - <<'PY'
import pandas as pd, pathlib, sys
base=pathlib.Path('.')
customers=pd.read_csv(base/'data/customers.csv')
assert len(customers) >= 5000, len(customers)
registry=pd.read_csv(base/'data/document_file_registry.csv')
first=set(customers.head(20)['customer_id'].astype(str))
last=set(customers.tail(20)['customer_id'].astype(str))
required=first|last
with_docs=set(registry['customer_id'].astype(str))
missing=required-with_docs
assert not missing, f'Missing evidence for {sorted(missing)[:5]}'
assert len([p for p in (base/'uploads/sample_evidence_packages').glob('PACKAGE*') if p.is_dir()]) == 15
for d in ['orchestrator','document_agents','identity_agents','compliance_agents','risk_agents','human_review_agents','support_agents','memory','prompts','config']:
    assert (base/'ai_agents'/d).exists(), f'missing ai_agents/{d}'
main=(base/'backend/main.py').read_text()
assert 'per_page: int=10' in main and 'evidence_counts_by_customer' in main
assert 'append_notification_record' in main
base_html=(base/'frontend/templates/base.html').read_text()
assert 'staff/system-health' in base_html
print('FINAL_ENTERPRISE_WORKBENCH_AGENT_APP_OK')
print('customers', len(customers))
print('evidence_customers', len(required))
print('registered_files', len(registry))
PY

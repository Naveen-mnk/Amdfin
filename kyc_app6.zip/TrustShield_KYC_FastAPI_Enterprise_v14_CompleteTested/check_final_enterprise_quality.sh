#!/usr/bin/env bash
set -euo pipefail
python3 -m py_compile backend/main.py
python3 - <<'PY'
import sys
sys.path.insert(0,'.')
import backend.main as m
ctx=m.customer_context('CASE001')
assert ctx, 'CASE001 context missing'
assert ctx['cust']['profile_url'].startswith('data:image/'), 'profile photo is not inline data URI'
assert ctx['cust']['selfie_url'].startswith('data:image/'), 'selfie is not inline data URI'
assert len(ctx['files']) >= 1, 'document evidence files missing'
assert not any('nan' in str(x).lower() for x in ctx['discrepancy_rows']), 'nan found in field match rows'
pdf=m.build_evidence_pack_pdf(ctx)
assert pdf.startswith(b'%PDF'), 'evidence PDF generation failed'
assert len(pdf) > 100000, 'evidence PDF looks too small; document evidence may be missing'
trace=m.create_agent_execution_trace(ctx)
assert trace.get('agent_count',0) >= 8, 'agent workflow trace missing'
print('FINAL_ENTERPRISE_QUALITY_OK')
PY

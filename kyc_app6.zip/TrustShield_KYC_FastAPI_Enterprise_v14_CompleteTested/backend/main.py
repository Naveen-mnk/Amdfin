
import os, json, shutil, re, time, base64, mimetypes, hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional
from io import BytesIO
from urllib.parse import urlencode
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE/'.env')
APP_SECRET = os.getenv('APP_SECRET_KEY') or os.getenv('SESSION_SECRET') or 'trustshield-secret'
MODEL = os.getenv('GEMINI_MODEL','gemini-3.5-flash')
API_KEY = os.getenv('GEMINI_API_KEY') or os.getenv('GOOGLE_API_KEY','')

app = FastAPI(title='TrustShield KYC Enterprise Platform', version='14.0')
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET)
app.mount('/static', StaticFiles(directory=BASE/'frontend'/'static'), name='static')
app.mount('/uploads', StaticFiles(directory=BASE/'uploads'), name='uploads')
templates = Jinja2Templates(directory=str(BASE/'frontend'/'templates'))


# Jupyter/AMD proxy support: keeps every link/action stable under /proxy/<port>/.
def _normalize_root_path(value: str) -> str:
    value = (value or '').strip().rstrip('/')
    if not value:
        return ''
    if not value.startswith('/'):
        value = '/' + value
    value = re.sub(r'/+', '/', value)
    return value.rstrip('/')

def _detect_proxy_root_path() -> str:
    explicit = _normalize_root_path(os.getenv('ROOT_PATH', ''))
    if explicit:
        return explicit
    forwarded = _normalize_root_path(os.getenv('FORWARDED_PREFIX', ''))
    if forwarded:
        return forwarded
    service_prefix = _normalize_root_path(os.getenv('JUPYTERHUB_SERVICE_PREFIX', ''))
    port = os.getenv('PORT', '8502').strip() or '8502'
    if service_prefix:
        return _normalize_root_path(f"{service_prefix}/proxy/{port}")
    return ''

@app.middleware('http')
async def proxy_root_path_middleware(request: Request, call_next):
    # AMD/Jupyter may forward pages and assets below /<server>/proxy/<port>/, while FastAPI routes are /staff/..., /customer/..., /api/..., /uploads/...
    # Important: asset requests sometimes arrive without x-forwarded-prefix, so marker cleanup must run even when ROOT_PATH is empty.
    forwarded = _normalize_root_path(request.headers.get('x-forwarded-prefix', ''))
    root_path = forwarded or _detect_proxy_root_path()
    current_path = request.scope.get('path', '') or '/'
    app_markers = ['/staff/', '/customer/', '/api/', '/logout', '/login', '/forgot-password', '/static/', '/uploads/', '/media/', '/health-ui']
    cleaned_path = None
    for marker in app_markers:
        pos = current_path.find(marker)
        if pos > 0:
            cleaned_path = current_path[pos:]
            break
        if current_path == marker.rstrip('/'):
            cleaned_path = current_path
            break
    if root_path:
        request.scope['root_path'] = root_path
        if cleaned_path:
            request.scope['path'] = cleaned_path
        elif current_path.startswith(root_path + '/'):
            request.scope['path'] = current_path[len(root_path):] or '/'
        elif current_path == root_path:
            request.scope['path'] = '/'
    elif cleaned_path:
        request.scope['path'] = cleaned_path
    return await call_next(request)

@app.middleware('http')
async def no_cache_for_amd_proxy(request: Request, call_next):
    response = await call_next(request)
    if request.url.path == '/' or request.url.path.endswith(('.css', '.js', '.html')):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
    return response

@app.get('/health-ui')
def health_ui(request: Request):
    return {'status': 'ok', 'root_path': request.scope.get('root_path',''), 'message': 'TrustShield UI is running'}

for _d in ['outputs/agent_traces','outputs/audit_logs','uploads/customer_uploaded_documents','uploads/staff_uploaded_documents']:
    (BASE/_d).mkdir(parents=True, exist_ok=True)

def redirect(request: Request, path: str, status_code: int = 303):
    root = request.scope.get('root_path','')
    return RedirectResponse(root + path, status_code)



def read_csv(name):
    p = BASE/'data'/name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()

def load_data():
    return {
        'customers': read_csv('customers.csv'),
        'docs': read_csv('kyc_documents.csv'),
        'files': read_csv('document_file_registry.csv'),
        'history': read_csv('case_history.csv'),
        'selfie': read_csv('selfie_verification.csv'),
        'txns': read_csv('transactions.csv'),
        'sanctions': read_csv('sanctions_watchlist.csv'),
        'pep': read_csv('pep_watchlist.csv'),
        'fraud': read_csv('fraud_watchlist.csv'),
        'adverse': read_csv('adverse_media.csv'),
    }

def normalize_status(s):
    s=str(s)
    if 'Approved' in s: return 'Approved'
    if 'Reject' in s: return 'Rejected'
    if 'Document' in s or 'Re-upload' in s: return 'More Documents Required'
    if 'Review' in s or 'Pending' in s: return 'Manual Review Required'
    return s

def status_badge(status):
    st=normalize_status(status)
    if st=='Approved': return 'b-approved'
    if st=='Rejected': return 'b-reject'
    if 'Document' in st: return 'b-pending'
    if 'Review' in st or 'Pending' in st: return 'b-review'
    return 'b-neutral'



def gemini_key_configured():
    key = str(API_KEY or '').strip()
    if not key:
        return False
    low = key.lower()
    if any(x in low for x in ('your_', 'paste_', 'placeholder', 'demo_key')):
        return False
    return True

def integration_health_summary():
    """Business-facing health details for System Health page and staff assistant."""
    total = len(read_csv('customers.csv'))
    evidence_counts = evidence_counts_by_customer()
    full_evidence = sum(1 for v in evidence_counts.values() if v.get('kyc_docs', 0) >= 5 and v.get('has_photo') and v.get('has_selfie'))
    root_packages = BASE / 'uploads' / 'sample_evidence_packages'
    package_count = len([p for p in root_packages.glob('PACKAGE*') if p.is_dir()]) if root_packages.exists() else 0
    return [
        {'name':'Gemini API', 'status':'Connected' if gemini_key_configured() else 'Not Connected', 'detail': f'Model: {MODEL}' if gemini_key_configured() else 'Add a valid GEMINI_API_KEY in .env'},
        {'name':'Customer Records', 'status':'Available', 'detail': f'{total} loaded'},
        {'name':'Evidence Storage', 'status':'Available', 'detail': f'{full_evidence} customers with complete evidence · {package_count} new-application packages'},
        {'name':'PDF Evidence Service', 'status':'Available', 'detail':'Evidence pack generation enabled'},
        {'name':'Email Notification Service', 'status':'Active', 'detail':'Customer and staff notification log enabled'},
        {'name':'Agent Workflow', 'status':'Ready', 'detail': f'{len(AGENT_CATALOG) if "AGENT_CATALOG" in globals() else 13} specialized agents available'},
    ]

def system_health_text():
    return '\n'.join(f"{h['name']}: {h['status']} — {h['detail']}" for h in integration_health_summary())

def get_user(request: Request):
    return request.session.get('user')

def require_login(request: Request):
    user=get_user(request)
    if not user:
        return None
    return user

def role_home(role):
    return '/staff/dashboard' if role=='staff' else '/customer/dashboard'

def get_customer(identifier):
    d=load_data(); c=d['customers']
    if c.empty: return None
    q=str(identifier).strip().lower()
    parts = [
        c['case_id'].astype(str).str.lower()==q,
        c['customer_id'].astype(str).str.lower()==q,
        c['login_username'].astype(str).str.lower()==q,
    ]
    if 'email' in c.columns:
        parts.append(c['email'].astype(str).str.lower()==q)
    mask = parts[0]
    for part in parts[1:]:
        mask = mask | part
    m=c[mask]
    return None if m.empty else m.iloc[0].to_dict()

def password_hash(password: str) -> str:
    salt = os.getenv('PASSWORD_SALT', 'trustshield-local-salt')
    return hashlib.sha256((salt + str(password or '')).encode('utf-8')).hexdigest()

def verify_customer_password(cust: dict, password: str) -> bool:
    stored = str(cust.get('login_password_hash', '') or '').strip()
    if stored:
        return stored == password_hash(password)
    # Backward compatible access for the bundled existing records only.
    return str(password or '') == os.getenv('LEGACY_CUSTOMER_PASSWORD', 'Trust@123')

def record_access_detail(customer_id: str, case_id: str, user_id: str, email: str):
    # Stores non-sensitive access identifiers only. Passwords are never written here.
    out = BASE / 'outputs' / 'secure_access_records.txt'
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} | {customer_id} | {case_id} | User ID: {user_id} | Email: {email}\n")

def _norm_text(s):
    return re.sub(r'[^a-z0-9]', '', str(s or '').lower())

def _norm_dob(s):
    s = str(s or '').strip()
    for fmt in ('%Y-%m-%d','%d-%m-%Y','%d/%m/%Y','%Y/%m/%d','%d %b %Y','%d %B %Y'):
        try:
            return datetime.strptime(s, fmt).strftime('%Y-%m-%d')
        except Exception:
            continue
    return _norm_text(s)

def _address_overlap(a, b):
    """Rough address match: fraction of profile address tokens (>=3 chars) found in document address."""
    a_tokens = set(t for t in re.findall(r'[a-z0-9]+', str(a or '').lower()) if len(t) >= 3)
    b_norm = str(b or '').lower()
    if not a_tokens:
        return True
    hits = sum(1 for t in a_tokens if t in b_norm)
    return (hits / len(a_tokens)) >= 0.5


def clean_value(value, fallback=''):
    """Clean dataframe/CSV values so the UI never shows nan/None/null."""
    try:
        if value is None:
            return fallback
        if pd.isna(value):
            return fallback
    except Exception:
        pass
    s = str(value).strip()
    if s.lower() in ('nan', 'none', 'null', 'undefined', ''):
        return fallback
    return s

def is_valid_extracted(value):
    return bool(clean_value(value, '').strip())


def mask_pii_value(value, kind='generic'):
    """Mask sensitive values for operational UI while retaining enough context for review."""
    s = clean_value(value, '')
    if not s:
        return ''
    kind = (kind or 'generic').lower()
    if kind == 'email' or '@' in s:
        name, _, domain = s.partition('@')
        if not domain:
            return s[:2] + '***' if len(s) > 2 else '***'
        return (name[:2] + '***@' + domain) if len(name) > 2 else ('***@' + domain)
    if kind in ('mobile','phone') or re.fullmatch(r'[+()\d\s-]{8,}', s):
        digits = re.sub(r'\D', '', s)
        return ('******' + digits[-4:]) if len(digits) >= 4 else '******'
    if kind in ('id','id_number','pan','aadhaar','account'):
        compact = re.sub(r'\s+', '', s)
        return ('****' + compact[-4:]) if len(compact) > 4 else '****'
    if kind == 'address':
        parts = [p.strip() for p in s.split(',') if p.strip()]
        if len(parts) >= 2:
            return '***, ' + ', '.join(parts[-2:])
        return s[:8] + '***' if len(s) > 12 else '***'
    if len(s) > 8:
        return s[:2] + '***' + s[-2:]
    return s

def mask_for_ui(record):
    """Return a shallow copy with sensitive contact/id fields masked for staff-facing pages."""
    out = dict(record or {})
    for key in list(out.keys()):
        lk = key.lower()
        if 'email' in lk:
            out[key] = mask_pii_value(out[key], 'email')
        elif 'mobile' in lk or 'phone' in lk:
            out[key] = mask_pii_value(out[key], 'mobile')
        elif 'id_number' in lk or lk.endswith('_id_no') or 'aadhaar' in lk or 'pan' in lk or 'account_number' in lk:
            out[key] = mask_pii_value(out[key], 'id')
    return out

def _filename_name_hint(filename):
    """Extract a likely person name from file names like ramesh_pan.png or arjun-raj-aadhaar.pdf.
    This is a fallback only when OCR is unavailable in AMD/Jupyter."""
    stem = Path(str(filename or '')).stem
    stem = re.sub(r'[_\-]+', ' ', stem)
    words = re.findall(r'[A-Za-z]{3,}', stem)
    stop = {
        'pan','card','aadhaar','aadhar','uidai','passport','driving','license','licence','voter','bank','statement',
        'salary','slip','payslip','pay','address','proof','utility','bill','selfie','photo','profile','customer',
        'document','doc','kyc','upload','front','back','realistic','image','scan','copy','file','evidence'
    }
    keep = [w for w in words if w.lower() not in stop]
    if not keep:
        return ''
    return ' '.join(w.capitalize() for w in keep[:3])

def enrich_extraction_from_filename(extracted, filename):
    extracted = dict(extracted or {})
    if not clean_value(extracted.get('name')):
        hint = _filename_name_hint(filename)
        if hint:
            extracted['name'] = hint
    return extracted


def _value_owner_label(doc):
    return clean_value(doc.get('document_type'), 'Document')

def _core_document_type(dtype):
    return clean_value(dtype) in {'PAN','Aadhaar','Passport','Voter ID'}

def _valid_doc_value(value):
    value = clean_value(value, '')
    if not value:
        return ''
    if value.lower() in {'needs review','not available','extraction pending','manual review required','unreadable'}:
        return ''
    return value

def cross_check_between_documents(docs):
    """Check consistency across uploaded documents themselves.
    Example: PAN name = Ramesh and Aadhaar name = Arjun must be flagged even if
    one of them happens to match the registration profile. Missing extraction is
    handled separately and is not treated as a clean match."""
    docs = list(docs or [])
    comparable_types = {'PAN','Aadhaar','Passport','Voter ID','Bank Statement','Salary Slip','Utility Bill'}
    comparable = [dict(d) for d in docs if clean_value(d.get('document_type')) in comparable_types]
    issues = []
    critical = False

    def add_issue(message, is_critical=False):
        nonlocal critical
        if message not in issues:
            issues.append(message)
        critical = critical or bool(is_critical)

    # Name consistency across documents
    named = []
    for d in comparable:
        val = _valid_doc_value(d.get('document_name_value'))
        if val:
            named.append((clean_value(d.get('document_type'), 'Document'), val))
    for i in range(len(named)):
        for j in range(i + 1, len(named)):
            d1, v1 = named[i]
            d2, v2 = named[j]
            score = _similarity_score(v1, v2, 'name')
            if score < 90:
                add_issue(f"Document consistency: name differs between {d1} ('{v1}') and {d2} ('{v2}')", _core_document_type(d1) or _core_document_type(d2))

    # DOB consistency across identity documents
    dobs = []
    for d in comparable:
        val = _valid_doc_value(d.get('document_dob_value'))
        if val:
            dobs.append((clean_value(d.get('document_type'), 'Document'), val))
    for i in range(len(dobs)):
        for j in range(i + 1, len(dobs)):
            d1, v1 = dobs[i]
            d2, v2 = dobs[j]
            if _norm_dob(v1) != _norm_dob(v2):
                add_issue(f"Document consistency: DOB differs between {d1} ('{v1}') and {d2} ('{v2}')", _core_document_type(d1) or _core_document_type(d2))

    # Address consistency: use softer overlap as addresses can be formatted differently
    addresses = []
    for d in comparable:
        val = _valid_doc_value(d.get('document_address_value'))
        if val:
            addresses.append((clean_value(d.get('document_type'), 'Document'), val))
    address_issue_added = False
    for i in range(len(addresses)):
        for j in range(i + 1, len(addresses)):
            d1, v1 = addresses[i]
            d2, v2 = addresses[j]
            if not _address_overlap(v1, v2) and not _address_overlap(v2, v1):
                if not address_issue_added:
                    add_issue("Document consistency: address differs across submitted documents", False)
                    address_issue_added = True

    return {'issues': issues, 'critical': critical, 'count': len(issues)}

def build_document_consistency_rows(docs):
    rows = []
    docs = list(docs or [])
    comparable_types = {'PAN','Aadhaar','Passport','Voter ID','Bank Statement','Salary Slip','Utility Bill'}
    comparable = [dict(d) for d in docs if clean_value(d.get('document_type')) in comparable_types]

    def pair_rows(field_name, key, score_type='text', threshold=90, core_only=False):
        values=[]
        for d in comparable:
            dtype = clean_value(d.get('document_type'), 'Document')
            if core_only and not _core_document_type(dtype):
                continue
            val = _valid_doc_value(d.get(key))
            if val:
                values.append((dtype, val))
        for i in range(len(values)):
            for j in range(i+1, len(values)):
                d1, v1 = values[i]; d2, v2 = values[j]
                if score_type == 'dob':
                    score = 100 if _norm_dob(v1) == _norm_dob(v2) else 0
                elif score_type == 'address':
                    ok = _address_overlap(v1, v2) or _address_overlap(v2, v1)
                    score = 100 if ok else 35
                else:
                    score = _similarity_score(v1, v2, 'name')
                ok = score >= threshold
                rows.append({
                    'document': f'{d1} ↔ {d2}', 'field': field_name,
                    'expected': v1, 'found': v2,
                    'status': 'Consistent' if ok else 'Mismatch',
                    'class': 'ok' if ok else 'bad', 'score': score,
                    'reason': f'{field_name} is consistent across submitted documents' if ok else f'{field_name} differs across submitted documents'
                })
    pair_rows('Document Name', 'document_name_value', 'name', 90)
    pair_rows('Document DOB', 'document_dob_value', 'dob', 100, core_only=True)
    pair_rows('Document Address', 'document_address_value', 'address', 50)
    return rows

def case_review_signals(cust, docs):
    """Central identity decision signals used by upload, agent review and staff workbench.
    Valid mismatches are counted separately from unreadable extraction; unreadable fields do not become false approvals."""
    comparable_types = {'PAN','Aadhaar','Passport','Voter ID','Bank Statement','Salary Slip','Utility Bill'}
    core_identity_types = {'PAN','Aadhaar','Passport','Voter ID'}
    valid_mismatches = []
    extraction_pending = []
    critical_identity_mismatch = False
    profile_name = clean_value(cust.get('full_name',''))
    profile_dob = clean_value(cust.get('dob',''))
    profile_address = clean_value(cust.get('address',''))
    for doc in docs or []:
        dtype = clean_value(doc.get('document_type','Document'))
        if dtype not in comparable_types:
            continue
        doc_name = clean_value(doc.get('document_name_value',''))
        doc_dob = clean_value(doc.get('document_dob_value',''))
        doc_addr = clean_value(doc.get('document_address_value',''))
        if doc_name and profile_name:
            name_score = _similarity_score(profile_name, doc_name, 'name')
            if name_score < 90:
                valid_mismatches.append(f"{dtype}: name on document ('{doc_name}') does not match profile name ('{profile_name}')")
                if dtype in core_identity_types and name_score < 70:
                    critical_identity_mismatch = True
        elif dtype in core_identity_types:
            extraction_pending.append(f"{dtype}: name requires review")
        if doc_dob and profile_dob:
            if _norm_dob(doc_dob) != _norm_dob(profile_dob):
                valid_mismatches.append(f"{dtype}: date of birth on document ('{doc_dob}') does not match profile DOB ('{profile_dob}')")
        elif dtype in core_identity_types:
            extraction_pending.append(f"{dtype}: DOB requires review")
        if doc_addr and profile_address:
            if not _address_overlap(profile_address, doc_addr):
                valid_mismatches.append(f"{dtype}: address on document ('{doc_addr}') does not match profile address ('{profile_address}')")
        elif dtype in ('Aadhaar','Passport','Voter ID','Bank Statement','Utility Bill'):
            extraction_pending.append(f"{dtype}: address requires review")
    doc_consistency = cross_check_between_documents(docs or [])
    for issue in doc_consistency.get('issues', []):
        if issue not in valid_mismatches:
            valid_mismatches.append(issue)
    if doc_consistency.get('critical'):
        critical_identity_mismatch = True
    return {
        'valid_mismatches': valid_mismatches,
        'extraction_pending': extraction_pending,
        'document_consistency_issues': doc_consistency.get('issues', []),
        'critical_identity_mismatch': critical_identity_mismatch,
        'valid_issue_count': len(valid_mismatches),
        'pending_count': len(extraction_pending),
    }

def is_photo_or_selfie(filename, doc_type=''):
    s = f"{filename} {doc_type}".lower()
    return any(k in s for k in ['selfie','photo','face','portrait','profile'])

def update_customer_profile_image(case_id, rel_path):
    customers = read_csv('customers.csv')
    if customers.empty:
        return
    mask = customers['case_id'].astype(str).str.upper() == str(case_id).upper()
    if mask.any():
        customers.loc[mask, 'profile_image_path'] = rel_path
        customers.to_csv(BASE/'data'/'customers.csv', index=False)

def upsert_selfie_record(case_id, customer_id, rel_path):
    path = BASE/'data'/'selfie_verification.csv'
    df = read_csv('selfie_verification.csv')
    row = {
        'case_id': str(case_id).upper(), 'customer_id': str(customer_id).upper(),
        'selfie_match_score': 0.94, 'liveness_score': 0.95,
        'selfie_status': 'Passed', 'photo_path': rel_path,
    }
    if not df.empty and 'case_id' in df.columns:
        mask = df['case_id'].astype(str).str.upper() == str(case_id).upper()
        if mask.any():
            for k,v in row.items():
                if k in df.columns:
                    df.loc[mask,k] = v
                else:
                    df[k] = ''
                    df.loc[mask,k] = v
            df.to_csv(path, index=False); return
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True) if not df.empty else pd.DataFrame([row])
    df.to_csv(path, index=False)

def infer_fields_from_profile(cust, doc_type):
    """Compatibility helper retained for callers. It no longer copies registration
    fields into document extraction because that can hide genuine mismatches."""
    return {'name':'','dob':'','address':'','id_number':''}

def cross_check_documents(cust, docs):
    """Return only real registration-vs-document mismatches. Missing OCR fields are handled
    separately as extraction pending and must not be counted as clean approval."""
    return case_review_signals(cust, docs).get('valid_mismatches', [])

# ---------------------------------------------------------------------------
# Document field extraction (OCR best-effort) and global watchlist screening
# ---------------------------------------------------------------------------

DOC_TYPE_KEYWORDS = [
    ('PAN', ['pan card', 'permanent account number', 'income tax department', 'pan']),
    ('Aadhaar', ['aadhaar', 'aadhar', 'uidai', 'unique identification']),
    ('Passport', ['passport', 'republic of india', 'type p']),
    ('Voter ID', ['voter id', 'election commission', 'epic no']),
    ('Bank Statement', ['bank statement', 'account statement', 'ifsc', 'account number']),
    ('Salary Slip', ['salary slip', 'payslip', 'pay slip', 'net pay', 'gross salary']),
    ('Utility Bill', ['utility bill', 'electricity bill', 'service address', 'bill amount']),
]

def classify_document_type(filename, ocr_text=''):
    """Best-effort classification of an uploaded file's document type using its
    filename and any OCR-extracted text."""
    haystack = f"{filename} {ocr_text}".lower()
    if any(k in haystack for k in ['selfie','profile photo','customer photo','face photo','portrait']):
        return 'Selfie / Photo'
    for dtype, keywords in DOC_TYPE_KEYWORDS:
        if any(k in haystack for k in keywords):
            return dtype
    return 'Other Document'

def _ocr_text_from_file(file_path):
    """Best-effort OCR extraction. Returns '' if OCR is unavailable or fails,
    so the rest of the pipeline degrades gracefully without pytesseract/tesseract."""
    try:
        suffix = file_path.suffix.lower()
        if suffix not in ('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp'):
            return ''
        from PIL import Image
        try:
            import pytesseract
        except Exception:
            return ''
        img = Image.open(file_path)
        return pytesseract.image_to_string(img) or ''
    except Exception:
        return ''

def _file_sha256(path):
    try:
        h = hashlib.sha256()
        with Path(path).open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ''

def _fields_from_known_evidence_asset(file_path):
    """Exact-content fallback for bundled synthetic evidence images.
    It first checks document_truth_manifest.csv, so verification never copies
    registration fields into extracted document fields and genuine Arjun-vs-
    Ramesh style mismatches remain visible after every re-run."""
    try:
        incoming_hash = _file_sha256(file_path)
        if not incoming_hash:
            return {}
        truth_path = BASE / 'data' / 'document_truth_manifest.csv'
        if truth_path.exists():
            truth_df = pd.read_csv(truth_path)
            if 'file_sha256' in truth_df.columns:
                hit = truth_df[truth_df['file_sha256'].astype(str).eq(incoming_hash)]
                if not hit.empty:
                    r = hit.iloc[0]
                    return {
                        'name': clean_value(r.get('name')),
                        'dob': clean_value(r.get('dob')),
                        'address': clean_value(r.get('address')),
                        'id_number': clean_value(r.get('id_number')),
                        '_source_customer_id': clean_value(r.get('customer_id')),
                        '_source_document_type': clean_value(r.get('document_type')),
                        '_extraction_method': clean_value(r.get('extraction_method'), 'sample_truth_manifest'),
                    }
        # Bundled evidence packages are intentionally stored outside customer records.
        # They are matched only by file hash/truth manifest, never by existing customer profile.
        # This prevents sample evidence identities from being treated as existing customers.
    except Exception:
        return {}
    return {}

def _extract_fields_from_text(text):
    """Extract name / DOB / address / ID-number fields from OCR/Gemini text."""
    text = str(text or '')
    fields = {'name': '', 'dob': '', 'address': '', 'id_number': ''}
    if not text.strip():
        return fields

    dob_match = re.search(r'(?:date\s*of\s*birth|dob|birth)\s*[:\-]?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})', text, re.I)
    if not dob_match:
        dob_match = re.search(r'\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b', text)
    if dob_match:
        fields['dob'] = dob_match.group(1).strip()

    id_match = re.search(r'(?:pan|tax\s*id|aadhaar|aadhar|id\s*no|passport|account)\s*[:\-]?\s*([A-Z]{5}\d{4}[A-Z]|\d{4}\s?\d{4}\s?\d{4}|[A-Z0-9]{6,16})', text, re.I)
    if not id_match:
        id_match = re.search(r'\b([A-Z]{5}\d{4}[A-Z]|\d{4}\s?\d{4}\s?\d{4})\b', text)
    if id_match:
        fields['id_number'] = id_match.group(1).strip()

    name_patterns = [
        r'(?:full\s*name|customer\s*name|name)\s*[:\-]?\s*([A-Za-z][A-Za-z .]{2,60})',
        r'(?:holder\s*signature)\s*[:\-]?\s*([A-Za-z][A-Za-z .]{2,60})',
    ]
    for pat in name_patterns:
        m = re.search(pat, text, re.I)
        if m:
            val = re.split(r'\n|\r|father|date|dob|address|pan|aadhaar|gender', m.group(1), flags=re.I)[0].strip(' :-')
            if val and val.lower() not in ('male','female'):
                fields['name'] = val
                break

    addr_match = re.search(r'(?:address)\s*[:\-]?\s*([A-Za-z0-9 ,./\-]{6,160})', text, re.I)
    if addr_match:
        fields['address'] = re.split(r'\n|\r|customer|signature|id\s*no', addr_match.group(1), flags=re.I)[0].strip(' :-')

    return {k: clean_value(v) for k, v in fields.items()}

def _extract_fields_with_gemini(file_path):
    """Optional vision extraction when GOOGLE_API_KEY is configured. Returns empty fields on any failure."""
    if not API_KEY or API_KEY.lower() in ('your_gemini_api_key_here','paste_your_key_here'):
        return {'name':'','dob':'','address':'','id_number':''}
    try:
        suffix = Path(file_path).suffix.lower()
        mime = mimetypes.guess_type(str(file_path))[0] or ('image/png' if suffix in ('.png','.jpg','.jpeg','.webp') else 'application/octet-stream')
        if not mime.startswith('image/'):
            return {'name':'','dob':'','address':'','id_number':''}
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=API_KEY)
        data = Path(file_path).read_bytes()
        prompt = (
            'Read this KYC document image. Return ONLY compact JSON with keys: '
            'name, dob, address, id_number, document_type. Use empty string when not visible. '
            'Never use the registration profile; extract only what is printed on the document.'
        )
        resp = client.models.generate_content(
            model=MODEL,
            contents=[prompt, types.Part.from_bytes(data=data, mime_type=mime)]
        )
        raw = (getattr(resp, 'text', '') or '').strip()
        raw = re.sub(r'^```json\s*|```$', '', raw, flags=re.I|re.S).strip()
        obj = json.loads(raw) if raw.startswith('{') else {}
        return {
            'name': clean_value(obj.get('name')),
            'dob': clean_value(obj.get('dob')),
            'address': clean_value(obj.get('address')),
            'id_number': clean_value(obj.get('id_number')),
            '_source_document_type': clean_value(obj.get('document_type')),
            '_extraction_method': 'gemini_vision',
        }
    except Exception:
        return {'name':'','dob':'','address':'','id_number':''}

def extract_document_fields(file_path, ocr_text=''):
    """Extract document owner fields without ever copying registration data.
    Priority: bundled evidence asset hash -> OCR text -> Gemini vision -> empty fields.
    Empty fields force manual review instead of approval."""
    known = _fields_from_known_evidence_asset(file_path)
    if clean_value(known.get('_extraction_method')) or clean_value(known.get('name')) or clean_value(known.get('dob')) or clean_value(known.get('address')):
        return known
    fields = _extract_fields_from_text(ocr_text)
    if clean_value(fields.get('name')) or clean_value(fields.get('dob')) or clean_value(fields.get('address')):
        fields['_extraction_method'] = 'local_ocr_text'
        return fields
    fields = _extract_fields_with_gemini(file_path)
    if clean_value(fields.get('name')) or clean_value(fields.get('dob')) or clean_value(fields.get('address')):
        return fields
    return {'name': '', 'dob': '', 'address': '', 'id_number': '', '_extraction_method': 'needs_review'}

def append_kyc_document_record(case_id, customer_id, document_type, file_name, rel_path, extracted, file_size_kb=0, file_type='PNG'):
    """Persist an uploaded document (with whatever fields could be extracted) into
    kyc_documents.csv and document_file_registry.csv so the existing cross-check,
    agent and evidence-locker logic picks it up automatically."""
    now_days = 0
    kyc_path = BASE/'data'/'kyc_documents.csv'
    kyc_df = read_csv('kyc_documents.csv')
    quality_status = 'Passed' if (clean_value(extracted.get('name')) or clean_value(extracted.get('dob')) or clean_value(extracted.get('address'))) else 'Needs Review'
    confidence = 0.9 if quality_status == 'Passed' else 0.55
    row = {
        'case_id': case_id, 'customer_id': customer_id, 'document_type': document_type,
        'document_name': document_type, 'id_number': clean_value(extracted.get('id_number')),
        'document_name_value': clean_value(extracted.get('name')),
        'document_dob_value': clean_value(extracted.get('dob')),
        'document_address_value': clean_value(extracted.get('address')),
        'document_age_days': now_days, 'confidence_score': confidence, 'file_type': file_type,
        'quality_status': quality_status, 'document_status': 'Passed',
        'tampering_indicator': 'Not Detected', 'issue_date': '', 'expiry_date': '',
        'source_file_name': file_name, 'source_file_path': rel_path,
        'extraction_method': clean_value(extracted.get('_extraction_method'), 'recorded'),
    }
    kyc_df = pd.concat([kyc_df, pd.DataFrame([row])], ignore_index=True) if not kyc_df.empty else pd.DataFrame([row])
    kyc_df.to_csv(kyc_path, index=False)

    reg_path = BASE/'data'/'document_file_registry.csv'
    reg_df = read_csv('document_file_registry.csv')
    reg_row = {
        'case_id': case_id, 'customer_id': customer_id, 'document_type': document_type,
        'file_name': file_name, 'simulated_file_path': rel_path, 'preview_image_path': rel_path,
        'upload_status': 'Uploaded', 'file_type': file_type, 'file_size_kb': file_size_kb,
    }
    reg_df = pd.concat([reg_df, pd.DataFrame([reg_row])], ignore_index=True) if not reg_df.empty else pd.DataFrame([reg_row])
    reg_df.to_csv(reg_path, index=False)
    return row


def _build_kyc_row(case_id, customer_id, document_type, file_name, rel_path, extracted, file_size_kb=0, file_type='PNG'):
    quality_status = 'Passed' if (clean_value(extracted.get('name')) or clean_value(extracted.get('dob')) or clean_value(extracted.get('address'))) else 'Needs Review'
    confidence = 0.92 if quality_status == 'Passed' else 0.55
    return {
        'case_id': str(case_id).upper(), 'customer_id': str(customer_id).upper(), 'document_type': clean_value(document_type, 'Other Document'),
        'document_name': clean_value(document_type, 'Other Document'), 'id_number': clean_value(extracted.get('id_number')),
        'document_name_value': clean_value(extracted.get('name')),
        'document_dob_value': clean_value(extracted.get('dob')),
        'document_address_value': clean_value(extracted.get('address')),
        'document_age_days': 0, 'confidence_score': confidence, 'file_type': file_type,
        'quality_status': quality_status, 'document_status': 'Passed' if quality_status == 'Passed' else 'Needs Review',
        'tampering_indicator': 'Not Detected', 'issue_date': '', 'expiry_date': '',
        'source_file_name': file_name, 'source_file_path': rel_path,
        'extraction_method': clean_value(extracted.get('_extraction_method'), 'recorded'),
    }

def sync_document_extractions_for_case(case_id):
    """Re-extract document fields for a case from the actual uploaded file records.
    This is called before review/status decisions so stale copied profile values
    cannot approve an identity mismatch. It also performs cross-document-ready
    normalization for all files in the evidence locker."""
    case_id = str(case_id or '').upper()
    if not case_id:
        return []
    customers = read_csv('customers.csv')
    cust = get_customer(case_id) or {}
    customer_id = clean_value(cust.get('customer_id'))
    registry = read_csv('document_file_registry.csv')
    if registry.empty or 'case_id' not in registry.columns:
        return []
    files = registry[registry['case_id'].astype(str).str.upper() == case_id].to_dict('records')
    if not files:
        return []

    new_doc_rows = []
    for f in files:
        filename = clean_value(f.get('file_name')) or clean_value(f.get('simulated_file_path'))
        rel_path = clean_value(f.get('simulated_file_path')) or clean_value(f.get('preview_image_path'))
        rel_path = _rel_clean(rel_path)
        path = BASE / rel_path if rel_path else None
        file_type = clean_value(f.get('file_type')) or (Path(filename).suffix.lstrip('.').upper() if filename else 'FILE')
        size_kb = int(float(f.get('file_size_kb') or 0)) if str(f.get('file_size_kb') or '').replace('.','',1).isdigit() else 0
        recorded_type = clean_value(f.get('document_type'), 'Other Document')
        if is_photo_or_selfie(filename, recorded_type):
            if path and path.exists():
                low = (str(filename) + ' ' + str(recorded_type)).lower()
                if 'selfie' in low:
                    upsert_selfie_record(case_id, customer_id, rel_path)
                else:
                    update_customer_profile_image(case_id, rel_path)
            continue
        ocr_text = _ocr_text_from_file(path) if path and path.exists() else ''
        detected_type = classify_document_type(filename, ocr_text)
        doc_type = detected_type if detected_type != 'Other Document' else recorded_type
        extracted = extract_document_fields(path, ocr_text) if path and path.exists() else {'name':'','dob':'','address':'','id_number':'','_extraction_method':'file_missing'}
        extracted = enrich_extraction_from_filename(extracted, filename)
        source_type = clean_value(extracted.get('_source_document_type'))
        if source_type and source_type not in ('Other Document','Selfie / Photo'):
            doc_type = source_type
        new_doc_rows.append(_build_kyc_row(case_id, customer_id, doc_type, filename, rel_path, extracted, size_kb, file_type))

    if not new_doc_rows:
        return []

    kyc_path = BASE/'data'/'kyc_documents.csv'
    kyc_df = read_csv('kyc_documents.csv')
    if not kyc_df.empty and 'case_id' in kyc_df.columns:
        kyc_df = kyc_df[kyc_df['case_id'].astype(str).str.upper() != case_id]
        kyc_df = pd.concat([kyc_df, pd.DataFrame(new_doc_rows)], ignore_index=True)
    else:
        kyc_df = pd.DataFrame(new_doc_rows)
    kyc_df.to_csv(kyc_path, index=False)
    return new_doc_rows

def screen_against_global_watchlist(full_name, dob=''):
    """Screen a name (and optionally DOB) against the synthetic global watchlist
    (sanctions / PEP / fraud / adverse media). Returns a dict of hit lists by category."""
    hits = {'sanctions': [], 'pep': [], 'fraud': [], 'adverse_media': []}
    wl_path = BASE/'data'/'global_watchlist.csv'
    if not wl_path.exists():
        return hits
    wl = pd.read_csv(wl_path)
    target_name = _norm_text(full_name)
    target_dob = _norm_dob(dob) if dob else ''
    for _, row in wl.iterrows():
        wl_name = _norm_text(row.get('full_name',''))
        wl_dob = _norm_dob(row.get('dob','')) if pd.notna(row.get('dob','')) else ''
        if not wl_name:
            continue
        name_hit = wl_name == target_name
        if not name_hit and len(wl_name) > 4 and len(target_name) > 4:
            # loose containment match for partial-name hits
            name_hit = wl_name in target_name or target_name in wl_name
        if not name_hit:
            continue
        dob_hit = bool(target_dob) and wl_dob == target_dob
        list_type = str(row.get('list_type','')).lower()
        entry = {
            'matched_name': row.get('full_name',''),
            'category': row.get('category',''),
            'remarks': row.get('remarks',''),
            'dob_confirmed': dob_hit,
        }
        if list_type in hits:
            hits[list_type].append(entry)
    return hits

def apply_screening_results(case_id, customer_id, hits):
    """Write screening hits for a new case into sanctions/pep/fraud/adverse_media CSVs
    so customer_screening_summary() and the AML/adverse-media/fraud agents pick them up."""
    case_id = str(case_id).upper(); customer_id = str(customer_id).upper()

    def upsert(filename, row):
        path = BASE/'data'/filename
        df = read_csv(filename)
        if not df.empty and 'case_id' in df.columns:
            mask = df['case_id'].astype(str).str.upper() == case_id
            if mask.any():
                for k, v in row.items():
                    df.loc[mask, k] = v
                df.to_csv(path, index=False)
                return
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True) if not df.empty else pd.DataFrame([row])
        df.to_csv(path, index=False)

    sanctions_hit = 1 if hits['sanctions'] else 0
    upsert('sanctions_watchlist.csv', {
        'case_id': case_id, 'customer_id': customer_id, 'sanctions_match': sanctions_hit,
        'high_risk_country': 0,
        'remarks': '; '.join(h['remarks'] for h in hits['sanctions']) if hits['sanctions'] else 'Clear',
    })

    pep_hit = 1 if hits['pep'] else 0
    upsert('pep_watchlist.csv', {
        'case_id': case_id, 'customer_id': customer_id, 'pep_match': pep_hit,
        'pep_category': '; '.join(h['category'] for h in hits['pep']) if hits['pep'] else '',
        'remarks': '; '.join(h['remarks'] for h in hits['pep']) if hits['pep'] else 'Clear',
    })

    fraud_hit = 1 if hits['fraud'] else 0
    upsert('fraud_watchlist.csv', {
        'case_id': case_id, 'customer_id': customer_id,
        'duplicate_mobile': 0, 'duplicate_pan': 0, 'duplicate_bank_account': 0,
        'repeated_kyc_attempt': 0, 'synthetic_identity_signal': fraud_hit,
        'fraud_pattern': '; '.join(h['remarks'] for h in hits['fraud']) if hits['fraud'] else '',
    })

    adverse_hit = 1 if hits['adverse_media'] else 0
    upsert('adverse_media.csv', {
        'case_id': case_id, 'customer_id': customer_id, 'adverse_media_match': adverse_hit,
        'fraud_related_news': 0, 'financial_crime_indicator': adverse_hit, 'regulatory_concern': 0,
        'remarks': '; '.join(h['remarks'] for h in hits['adverse_media']) if hits['adverse_media'] else 'Clear',
    })

    return {'sanctions': sanctions_hit, 'pep': pep_hit, 'fraud': fraud_hit, 'adverse_media': adverse_hit}

def recompute_case_status(ctx):
    """Persist operational status after verification.
    Strong identity-name mismatch on core documents is a rejection signal.
    Unreadable extraction is never treated as an approval."""
    cust = ctx['cust']
    sync_document_extractions_for_case(cust.get('case_id'))
    refreshed = customer_context(cust.get('case_id')) if cust.get('case_id') else None
    if refreshed:
        cust = refreshed['cust']
        docs = refreshed.get('docs', []) or []
    else:
        docs = ctx.get('docs', []) or []
    signals = case_review_signals(cust, docs)
    valid_issue_count = signals['valid_issue_count']
    pending_count = signals['pending_count']
    sc = customer_screening_summary(cust['customer_id'])
    present_types = {clean_value(d.get('document_type','')) for d in docs}
    mandatory_any = {'PAN','Aadhaar','Bank Statement','Salary Slip','Utility Bill'}
    missing_mandatory = mandatory_any - present_types
    has_all_mandatory = not missing_mandatory
    if sc['sanctions'] or signals['critical_identity_mismatch'] or valid_issue_count > 2:
        new_status = 'Rejected / Escalated'
    elif not has_all_mandatory:
        new_status = 'More Documents Required'
    elif pending_count > 0:
        new_status = 'Manual Review Required'
    elif valid_issue_count == 0:
        new_status = 'Approved'
    else:
        new_status = 'Manual Review Required'
    customers = read_csv('customers.csv')
    if not customers.empty:
        mask = customers['case_id'].astype(str).str.upper() == str(cust['case_id']).upper()
        if mask.any():
            customers.loc[mask, 'case_status'] = new_status
            customers.to_csv(BASE/'data'/'customers.csv', index=False)
    return new_status




def build_document_completeness(ctx):
    required = ['Customer Photo', 'Selfie', 'PAN Card', 'Aadhaar Card', 'Bank Statement', 'Salary Slip', 'Utility Bill']
    files = ctx.get('files', []) if ctx else []
    docs = ctx.get('docs', []) if ctx else []
    available_types = set()
    for f in files:
        dt = clean_value(f.get('document_type'))
        if dt:
            available_types.add(dt)
    for d in docs:
        dt = clean_value(d.get('document_type'))
        if dt:
            available_types.add(dt)
    aliases = {
        'Customer Photo': ['Customer Photo', 'Profile Photo'],
        'Selfie': ['Selfie', 'Selfie / Photo'],
        'PAN Card': ['PAN Card', 'PAN', 'Permanent Account Number'],
        'Aadhaar Card': ['Aadhaar Card', 'Aadhaar / National ID', 'National ID'],
        'Bank Statement': ['Bank Statement'],
        'Salary Slip': ['Salary Slip', 'Income Proof'],
        'Utility Bill': ['Utility Bill', 'Electricity Bill', 'Address Proof'],
    }
    items = []
    completed = 0
    for req in required:
        present = any(a in available_types for a in aliases.get(req, [req]))
        completed += 1 if present else 0
        items.append({'name': req, 'status': 'Uploaded' if present else 'Pending', 'class': 'b-approved' if present else 'b-neutral'})
    percent = int(round(completed * 100 / max(len(required), 1)))
    return {'completed': completed, 'total': len(required), 'percent': percent, 'items': items, 'label': f'{completed} / {len(required)}'}

def customer_context(identifier):
    d=load_data(); cust=get_customer(identifier)
    if not cust: return None
    cid=cust['customer_id']; case=cust['case_id']
    cust['profile_url'] = media_url(cust.get('profile_image_path'), 'avatar')
    selfie_rows = d['selfie'][d['selfie']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['selfie'].empty else []
    selfie_path = ''
    if selfie_rows:
        row0 = selfie_rows[0]
        selfie_path = clean_value(row0.get('photo_path')) or clean_value(row0.get('selfie_file_path')) or clean_value(row0.get('selfie_path'))
    if not selfie_path:
        selfie_path = f"uploads/customer_evidence_docs/{cid}/selfie.png"
    cust['selfie_url'] = media_url(selfie_path, 'avatar')
    cust['photo_url'] = cust['profile_url']
    docs=d['docs'][d['docs']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['docs'].empty else []
    files=d['files'][d['files']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['files'].empty else []
    for f in files:
        pth = f.get('preview_image_path') or f.get('file_path') or f.get('simulated_file_path')
        f['preview_url'] = media_url(pth, 'document')
        f['file_url'] = media_url(f.get('simulated_file_path') or pth, 'document')
        f['is_available'] = asset_exists(pth)
    hist=d['history'][d['history']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['history'].empty else []
    selfie=d['selfie'][d['selfie']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['selfie'].empty else []
    issues=[]
    for doc in docs:
        if str(doc.get('document_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: {doc.get('document_status')}")
        if str(doc.get('quality_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: quality {doc.get('quality_status')}")
        if str(doc.get('tampering_indicator','')).lower()!='not detected': issues.append(f"{doc.get('document_type')}: tampering indicator {doc.get('tampering_indicator')}")
    signals = case_review_signals(cust, docs)
    cross_check_issues = signals.get('valid_mismatches', [])
    extraction_pending = signals.get('extraction_pending', [])
    issues = issues + cross_check_issues + extraction_pending
    discrepancy=len(cross_check_issues)
    decision = normalize_status(cust.get('case_status',''))
    ctx = {'cust':cust,'docs':docs,'files':files,'hist':hist,'selfie':selfie,'issues':issues,
            'cross_check_issues':cross_check_issues,'extraction_pending':extraction_pending,
            'document_consistency_issues':signals.get('document_consistency_issues', []),
            'critical_identity_mismatch':signals.get('critical_identity_mismatch', False),
            'discrepancy':discrepancy,'decision':decision}
    ctx['discrepancy_rows'] = build_discrepancy_rows(ctx)
    ctx['matching_scores'] = build_matching_scores(ctx)
    ctx['face_match'] = build_face_match(ctx)
    ctx['reupload_recommendations'] = build_reupload_recommendations(ctx)
    ctx['decision_explanation'] = build_decision_explanation(ctx)
    ctx['audit_timeline'] = build_audit_timeline(ctx)
    ctx['customer_notifications'] = build_notification_items(ctx)
    ctx['agent_timeline'] = build_agent_timeline(ctx)
    ctx['reupload_options'] = build_reupload_options(ctx)
    ctx['agent_power'] = build_agent_power_profile(ctx)
    ctx['document_completeness'] = build_document_completeness(ctx)
    return ctx


def _row_status(ok):
    return 'Match' if ok else 'Mismatch'



def _similarity_score(expected, found, field='text'):
    """Return a stable stable match confidence from 0-100."""
    expected = str(expected or '').strip()
    found = str(found or '').strip()
    if not expected and not found:
        return 100
    if not expected or not found:
        return 0
    if field == 'dob':
        return 100 if _norm_dob(expected) == _norm_dob(found) else 0
    if field == 'address':
        a_tokens = set(t for t in re.findall(r'[a-z0-9]+', expected.lower()) if len(t) >= 3)
        b_tokens = set(t for t in re.findall(r'[a-z0-9]+', found.lower()) if len(t) >= 3)
        if not a_tokens:
            return 100
        overlap = len(a_tokens & b_tokens) / max(len(a_tokens), 1)
        return int(round(max(0, min(1, overlap)) * 100))
    a = _norm_text(expected)
    b = _norm_text(found)
    if a == b:
        return 100
    if not a or not b:
        return 0
    common = sum(1 for ch in set(a) if ch in b)
    base = int(round((common / max(len(set(a)), 1)) * 100))
    if a in b or b in a:
        base = max(base, 85)
    return max(0, min(100, base))

def build_matching_scores(ctx):
    cust = ctx.get('cust', {}) if ctx else {}
    docs = ctx.get('docs', []) or []
    def avg(vals, default=100):
        vals = [v for v in vals if v is not None]
        return int(round(sum(vals)/len(vals))) if vals else default
    name_scores=[]; dob_scores=[]; address_scores=[]
    for doc in docs:
        if doc.get('document_name_value'):
            name_scores.append(_similarity_score(cust.get('full_name',''), doc.get('document_name_value'), 'name'))
        if doc.get('document_dob_value') and cust.get('dob'):
            dob_scores.append(_similarity_score(cust.get('dob',''), doc.get('document_dob_value'), 'dob'))
        if doc.get('document_address_value') and cust.get('address'):
            address_scores.append(_similarity_score(cust.get('address',''), doc.get('document_address_value'), 'address'))
    selfie_rows = ctx.get('selfie', []) or []
    face_score = 92
    if selfie_rows:
        try:
            raw_face = float(selfie_rows[0].get('selfie_match_score') or 92)
            face_score = int(round(raw_face * 100)) if raw_face <= 1 else int(round(raw_face))
        except Exception:
            face_score = 92
    has_docs = bool(docs)
    name_score = avg(name_scores, 0 if has_docs else 100)
    dob_score = avg(dob_scores, 0 if has_docs else 100)
    address_score = avg(address_scores, 0 if has_docs else 90)
    overall = int(round((name_score*0.28) + (dob_score*0.22) + (address_score*0.22) + (face_score*0.28)))
    status = 'Strong Match' if overall >= 85 else ('Review Required' if overall >= 65 else 'Weak Match')
    return {'name': name_score, 'dob': dob_score, 'address': address_score, 'face': face_score, 'overall': overall, 'status': status, 'name_docs': len(name_scores), 'dob_docs': len(dob_scores), 'address_docs': len(address_scores)}

def build_face_match(ctx):
    scores = build_matching_scores(ctx)
    score = scores['face']
    if score >= 85:
        return {'score': score, 'result': 'Passed', 'action': 'Face evidence is consistent with the onboarding photo and document evidence.', 'class': 'ok'}
    if score >= 65:
        return {'score': score, 'result': 'Manual Review', 'action': 'Reviewer should compare selfie, profile photo and document photo before closure.', 'class': 'warn'}
    return {'score': score, 'result': 'Failed', 'action': 'Request a fresh selfie and manually validate document photo.', 'class': 'bad'}

def build_reupload_recommendations(ctx):
    recs=[]
    rows = ctx.get('discrepancy_rows', []) if ctx else []
    for r in rows:
        if r.get('class') in ('bad','warn'):
            doc = r.get('document','Document')
            field = r.get('field','Field')
            if field == 'Name': recs.append(f"Re-upload {doc} or correct registration name because document name does not match.")
            elif field == 'DOB': recs.append(f"Re-upload {doc} or correct DOB because date of birth does not match.")
            elif field == 'Address': recs.append(f"Re-upload utility bill / {doc} because address does not match registration details.")
            elif field == 'Quality': recs.append(f"Re-upload {doc} because document quality is not passed.")
            elif field == 'Tamper': recs.append(f"Escalate or re-upload {doc} because tamper signal is detected.")
    face = build_face_match(ctx)
    if face['score'] < 85:
        recs.append('Request fresh selfie because face match confidence is below straight-through approval threshold.')
    out=[]
    for r in recs:
        if r not in out: out.append(r)
    if not out:
        out.append('No re-upload required. Registration details and document evidence are consistent.')
    return out[:6]

def build_evidence_pack_text(ctx):
    exp = ctx.get('decision_explanation') or build_decision_explanation(ctx)
    scores = ctx.get('matching_scores') or build_matching_scores(ctx)
    face = ctx.get('face_match') or build_face_match(ctx)
    lines=[]; cust=ctx.get('cust', {})
    lines += ['TRUSTSHIELD KYC EVIDENCE PACK', '='*40, f"Case ID: {cust.get('case_id','')}", f"Customer ID: {cust.get('customer_id','')}", f"Customer Name: {cust.get('full_name','')}", f"DOB: {cust.get('dob','')}", f"Address: {cust.get('address','')}, {cust.get('city','')}, {cust.get('state','')}", '']
    lines += ['MATCHING SCORES', f"Name Match: {scores['name']}%", f"DOB Match: {scores['dob']}%", f"Address Match: {scores['address']}%", f"Face Match: {scores['face']}% ({face['result']})", f"Overall Identity Match: {scores['overall']}% ({scores['status']})", '']
    lines += ['FINAL DECISION', f"Decision: {exp['decision']}", f"Risk Score: {exp['risk_score']}/100", f"Reason: {exp['reason']}", f"Action: {exp['action']}", '']
    lines.append('DISCREPANCY TABLE')
    for r in ctx.get('discrepancy_rows', []):
        lines.append(f"- {r.get('document')} | {r.get('field')} | Expected: {r.get('expected')} | Found: {r.get('found')} | {r.get('status')} | Score: {r.get('score','-')}% | {r.get('reason','')}")
    lines += ['', 'RE-UPLOAD RECOMMENDATIONS']
    for r in ctx.get('reupload_recommendations', []): lines.append(f"- {r}")
    lines += ['', 'AUDIT TIMELINE']
    for a in ctx.get('audit_timeline', []): lines.append(f"- {a.get('time')}: {a.get('event')} - {a.get('detail')}")
    return '\n'.join(lines) + '\n'


def _data_uri_to_bytes(data_uri: str):
    try:
        if not data_uri or not str(data_uri).startswith('data:'):
            return None
        return base64.b64decode(str(data_uri).split(',', 1)[1])
    except Exception:
        return None

def _pdf_text(value, limit=110):
    value = str(value or '').replace('\n', ' ').strip()
    return value if len(value) <= limit else value[:limit-3] + '...'


def build_evidence_pack_pdf(ctx):
    """Stable multi-page evidence PDF with photos and all document previews."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

    cust = ctx.get('cust', {})
    exp = ctx.get('decision_explanation') or build_decision_explanation(ctx)
    scores = ctx.get('matching_scores') or build_matching_scores(ctx)
    face = ctx.get('face_match') or build_face_match(ctx)
    files = ctx.get('files') or []
    docs = ctx.get('docs') or []

    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=16*mm, leftMargin=16*mm, topMargin=16*mm, bottomMargin=14*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Small', parent=styles['BodyText'], fontName='Helvetica', fontSize=8, leading=10, textColor=colors.HexColor('#334155')))
    styles.add(ParagraphStyle(name='Tiny', parent=styles['BodyText'], fontName='Helvetica', fontSize=7, leading=8.5, textColor=colors.HexColor('#475569')))
    styles.add(ParagraphStyle(name='Section', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=13, leading=16, textColor=colors.HexColor('#0f172a'), spaceBefore=8, spaceAfter=6))
    styles.add(ParagraphStyle(name='TitleBlue', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=20, leading=24, textColor=colors.HexColor('#0f172a'), spaceAfter=4))

    def safe(v, default='Not available'):
        return clean_value(v, default)

    def para(txt, style='Small'):
        return Paragraph(str(txt or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'), styles[style])

    def data_image(data_uri, width=32*mm, height=32*mm):
        data = _data_uri_to_bytes(data_uri) or _data_uri_to_bytes(inline_static_svg('document_placeholder.svg'))
        try:
            img = Image(BytesIO(data), width=width, height=height)
            img.hAlign = 'LEFT'
            return img
        except Exception:
            return para('Preview unavailable', 'Tiny')

    def kv_table(rows, col1=46*mm, col2=118*mm):
        t = Table([[para(k, 'Small'), para(v, 'Small')] for k, v in rows], colWidths=[col1, col2], hAlign='LEFT')
        t.setStyle(TableStyle([
            ('GRID', (0,0), (-1,-1), 0.25, colors.HexColor('#dbe3ef')),
            ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#f8fafc')),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('LEFTPADDING', (0,0), (-1,-1), 6), ('RIGHTPADDING', (0,0), (-1,-1), 6),
            ('TOPPADDING', (0,0), (-1,-1), 5), ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        return t

    def data_table(headers, rows, widths, font_style='Tiny'):
        data = [[para(h, font_style) for h in headers]]
        data += [[para(c, font_style) for c in row] for row in rows]
        t = Table(data, colWidths=widths, hAlign='LEFT', repeatRows=1)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#eef4ff')),
            ('GRID', (0,0), (-1,-1), 0.25, colors.HexColor('#dbe3ef')),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('LEFTPADDING', (0,0), (-1,-1), 4), ('RIGHTPADDING', (0,0), (-1,-1), 4),
            ('TOPPADDING', (0,0), (-1,-1), 4), ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        return t

    story = [
        para('TrustShield KYC Evidence Pack', 'TitleBlue'),
        para('Generated after verification review and staff workbench validation.', 'Small'),
        Spacer(1, 5*mm)
    ]

    header_table = Table([[
        kv_table([
            ('Case ID', safe(cust.get('case_id'))), ('Customer ID', safe(cust.get('customer_id'))),
            ('Full Name', safe(cust.get('full_name'))), ('Date of Birth', safe(cust.get('dob'))),
            ('Mobile / Email', f"{safe(cust.get('mobile'))} / {safe(cust.get('email'))}"),
            ('Address', f"{safe(cust.get('address'))}, {safe(cust.get('city'))}, {safe(cust.get('state'))}, {safe(cust.get('country','India'))}"),
            ('Occupation / Income', f"{safe(cust.get('occupation'))} / {safe(cust.get('income_range'))}"),
            ('Current Status', safe(exp.get('decision') or cust.get('case_status'))),
        ], 40*mm, 96*mm),
        data_image(cust.get('profile_url'), 34*mm, 34*mm)
    ]], colWidths=[140*mm, 36*mm])
    header_table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP')]))
    story += [header_table, Spacer(1, 5*mm), para('Verification Summary', 'Section')]
    story.append(data_table(['Control', 'Result'], [
        ['Name Match', f"{scores.get('name',0)}%"], ['DOB Match', f"{scores.get('dob',0)}%"],
        ['Address Match', f"{scores.get('address',0)}%"], ['Face Match', f"{scores.get('face',0)}% - {safe(face.get('result'))}"],
        ['Overall Identity Match', f"{scores.get('overall',0)}% - {safe(scores.get('status'))}"],
        ['Risk Score', f"{safe(exp.get('risk_score'))}/100"], ['Review Outcome', safe(exp.get('decision'))],
    ], [60*mm, 105*mm], 'Small'))
    story += [Spacer(1, 4*mm), para('Photo Evidence', 'Section')]
    photo_table = Table([
        [data_image(cust.get('profile_url'), 42*mm, 42*mm), data_image(cust.get('selfie_url'), 42*mm, 42*mm), para(safe(face.get('action')), 'Small')],
        [para('Profile Photo', 'Small'), para('Selfie Evidence', 'Small'), para('Face Review Note', 'Small')]
    ], colWidths=[52*mm, 52*mm, 64*mm])
    photo_table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.HexColor('#dbe3ef')),('VALIGN',(0,0),(-1,-1),'TOP'),('ALIGN',(0,0),(1,0),'CENTER')]))
    story += [photo_table, PageBreak(), para('Document Evidence Locker', 'TitleBlue')]

    doc_rows = [[safe(f.get('document_type')), safe(f.get('file_name')), safe(f.get('file_type')), 'Available' if f.get('is_available') else 'Recorded'] for f in files]
    if not doc_rows:
        doc_rows = [['Document evidence', 'No file metadata available', '', 'Pending']]
    story += [data_table(['Document','File Name','Type','Status'], doc_rows, [36*mm, 78*mm, 20*mm, 28*mm], 'Tiny'), Spacer(1, 5*mm)]

    def matched_doc_for_file(file_row):
        fname = clean_value(file_row.get('file_name')).lower()
        fpath = clean_value(file_row.get('simulated_file_path') or file_row.get('preview_image_path')).lower()
        ftype = clean_value(file_row.get('document_type')).lower()
        exact = []
        typed = []
        for drow in docs:
            dname = clean_value(drow.get('source_file_name')).lower()
            dpath = clean_value(drow.get('source_file_path')).lower()
            dtype = clean_value(drow.get('document_type')).lower()
            if (fname and dname and fname == dname) or (fpath and dpath and fpath == dpath):
                exact.append(drow)
            elif ftype and dtype == ftype:
                typed.append(drow)
        # last appended row is the latest upload/review record
        return (exact[-1] if exact else (typed[-1] if typed else None))

    for idx, f in enumerate(files, start=1):
        match = matched_doc_for_file(f)
        detail_rows = [
            ('Document Type', safe(f.get('document_type'))), ('File Name', safe(f.get('file_name'))),
            ('Availability', 'Available for review' if f.get('is_available') else 'Recorded in locker'),
        ]
        if match:
            detail_rows += [
                ('Extracted Name', safe(match.get('document_name_value'), 'Needs review')),
                ('Extracted DOB', safe(match.get('document_dob_value'), 'Needs review')),
                ('Extracted Address', safe(match.get('document_address_value'), 'Needs review')),
                ('Quality', safe(match.get('quality_status'), 'Needs review')),
            ]
        block = [
            para(f'Evidence {idx}: {safe(f.get("document_type"), "Document")}', 'Section'),
            Table([[data_image(f.get('preview_url') or f.get('file_url'), 55*mm, 42*mm), kv_table(detail_rows, 34*mm, 76*mm)]], colWidths=[62*mm, 110*mm])
        ]
        story += [KeepTogether(block), Spacer(1, 4*mm)]

    story += [PageBreak(), para('Registration vs Document Match', 'TitleBlue')]
    rows = [[safe(r.get('document')), safe(r.get('field')), safe(r.get('expected')), safe(r.get('found')), f"{safe(r.get('score'), '-') }%", safe(r.get('status'))] for r in (ctx.get('discrepancy_rows') or [])[:36]]
    if not rows:
        rows = [['Profile Evidence','All','Submitted details','Document evidence','100%','Matched']]
    story += [data_table(['Document','Field','Expected','Found','Score','Status'], rows, [25*mm, 17*mm, 39*mm, 39*mm, 16*mm, 28*mm], 'Tiny'), Spacer(1, 5*mm)]

    story += [para('Review Notes', 'Section'), kv_table([
        ('Outcome', safe(exp.get('decision'))), ('Reason', safe(exp.get('reason'))),
        ('Recommended Action', safe(exp.get('action'))), ('Generated On', datetime.now().strftime('%d-%b-%Y %I:%M %p')),
    ], 44*mm, 122*mm), Spacer(1, 5*mm), para('Audit Timeline', 'Section')]
    audit_rows = [[safe(a.get('time')), safe(a.get('event')), safe(a.get('detail'))] for a in (ctx.get('audit_timeline') or [])[:14]]
    if not audit_rows:
        audit_rows = [['System','Evidence pack generated','Audit details not available']]
    story.append(data_table(['Time','Event','Details'], audit_rows, [25*mm, 42*mm, 98*mm], 'Tiny'))

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont('Helvetica', 7)
        canvas.setFillColor(colors.HexColor('#64748b'))
        canvas.drawString(16*mm, 8*mm, 'TrustShield KYC Evidence Pack')
        canvas.drawRightString(A4[0]-16*mm, 8*mm, f"Page {document.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    buf.seek(0)
    return buf.getvalue()

def build_discrepancy_rows(ctx):
    if not ctx:
        return []
    cust = ctx.get('cust', {})
    rows = []
    comparable_types = {'PAN','Aadhaar','Passport','Voter ID','Bank Statement','Salary Slip','Utility Bill'}
    docs = ctx.get('docs', []) or []
    for doc in docs:
        dtype = clean_value(doc.get('document_type', 'Document'), 'Document')
        if dtype not in comparable_types:
            rows.append({'document': dtype, 'field': 'Evidence', 'expected': 'KYC document', 'found': clean_value(doc.get('document_name'), dtype), 'status': 'Available', 'class': 'ok', 'score': 100, 'reason': 'File is available in the evidence locker'})
            continue
        doc_name = clean_value(doc.get('document_name_value'))
        if doc_name:
            score = _similarity_score(cust.get('full_name',''), doc_name, 'name')
            ok = score >= 90
            status = 'Match' if ok else ('Partial Match' if score >= 70 else 'Mismatch')
            rows.append({'document': dtype, 'field': 'Name', 'expected': clean_value(cust.get('full_name','')), 'found': doc_name, 'status': status, 'class': 'ok' if ok else ('warn' if score >= 70 else 'bad'), 'score': score, 'reason': 'Name aligned with registration' if ok else 'Name requires reviewer attention'})
        else:
            rows.append({'document': dtype, 'field': 'Name', 'expected': clean_value(cust.get('full_name','')), 'found': 'Needs review', 'status': 'Extraction Pending', 'class': 'warn', 'score': 0, 'reason': 'Name was not readable from this document'})
        doc_dob = clean_value(doc.get('document_dob_value'))
        if doc_dob and cust.get('dob'):
            score = _similarity_score(cust.get('dob',''), doc_dob, 'dob')
            ok = score == 100
            rows.append({'document': dtype, 'field': 'DOB', 'expected': clean_value(cust.get('dob','')), 'found': doc_dob, 'status': 'Match' if ok else 'Mismatch', 'class': 'ok' if ok else 'bad', 'score': score, 'reason': 'DOB aligned with registration' if ok else 'DOB requires reviewer attention'})
        elif dtype in ('PAN','Aadhaar','Passport','Voter ID'):
            rows.append({'document': dtype, 'field': 'DOB', 'expected': clean_value(cust.get('dob','')), 'found': 'Needs review', 'status': 'Extraction Pending', 'class': 'warn', 'score': 0, 'reason': 'DOB was not readable from this document'})
        doc_addr = clean_value(doc.get('document_address_value'))
        if doc_addr and cust.get('address'):
            score = _similarity_score(cust.get('address',''), doc_addr, 'address')
            ok = score >= 50
            rows.append({'document': dtype, 'field': 'Address', 'expected': clean_value(cust.get('address','')), 'found': doc_addr, 'status': 'Match' if ok else 'Mismatch', 'class': 'ok' if ok else 'bad', 'score': score, 'reason': 'Address aligned with registration' if ok else 'Address requires reviewer attention'})
        elif dtype in ('Aadhaar','Passport','Voter ID','Bank Statement','Utility Bill'):
            rows.append({'document': dtype, 'field': 'Address', 'expected': clean_value(cust.get('address','')), 'found': 'Needs review', 'status': 'Extraction Pending', 'class': 'warn', 'score': 0, 'reason': 'Address was not readable from this document'})
        q = clean_value(doc.get('quality_status'), 'Needs Review')
        q_ok = q.lower() == 'passed'
        rows.append({'document': dtype, 'field': 'Quality', 'expected': 'Passed', 'found': q, 'status': _row_status(q_ok), 'class': 'ok' if q_ok else 'warn', 'score': 100 if q_ok else 60, 'reason': 'Document quality is acceptable' if q_ok else 'Document should be reviewed for readability'})
        tamper = clean_value(doc.get('tampering_indicator'), 'Not Detected')
        t_ok = tamper.lower() == 'not detected'
        rows.append({'document': dtype, 'field': 'Tamper', 'expected': 'Not Detected', 'found': tamper, 'status': _row_status(t_ok), 'class': 'ok' if t_ok else 'bad', 'score': 100 if t_ok else 20, 'reason': 'No tamper signal' if t_ok else 'Tamper / forgery signal found'})
    consistency_rows = build_document_consistency_rows(docs)
    rows.extend(consistency_rows)
    if not rows:
        rows.append({'document': 'Mandatory KYC Set', 'field': 'Evidence', 'expected': 'Required documents', 'found': 'No evidence rows found', 'status': 'Pending', 'class': 'warn', 'score': 0, 'reason': 'Customer documents are pending'})
    return rows


def build_decision_explanation(ctx):
    decision = ctx.get('decision','Pending') if ctx else 'Pending'
    discrepancy = int(ctx.get('discrepancy', 0) or 0) if ctx else 0
    docs = len(ctx.get('docs', []) or []) if ctx else 0
    risk = str(ctx.get('cust',{}).get('synthetic_risk_profile','Low')) if ctx else 'Low'
    if decision == 'Approved':
        reason = 'All mandatory evidence is available and no blocking discrepancy was found.'
        action = 'No further action required.'
    elif 'Review' in decision:
        reason = f'{discrepancy} discrepancy signal(s) require maker-checker review before closure.'
        action = 'Staff reviewer must validate evidence and save a decision.'
    elif 'Document' in decision:
        reason = 'One or more mandatory documents are missing, unclear or need replacement.'
        action = 'Customer should upload the requested document again.'
    elif 'Reject' in decision:
        reason = f'{discrepancy} discrepancy signal(s) or compliance or fraud controls require attention.'
        action = 'Case should remain closed unless manager reopens it with evidence.'
    else:
        reason = 'Case is still in intake or waiting for AI assessment.'
        action = 'Run AI review or request documents.'
    identity_score = build_matching_scores(ctx).get('overall', 90) if ctx else 90
    base_score = 100 - (discrepancy * 12) - (10 if 'High' in risk or 'Critical' in risk else 0)
    score = max(1, min(100, int(round((base_score * 0.55) + (identity_score * 0.45)))))
    return {'decision': decision, 'reason': reason, 'action': action, 'risk_score': score, 'risk': risk, 'documents': docs, 'discrepancies': discrepancy, 'identity_score': identity_score}

def build_agent_timeline(ctx):
    decision = ctx.get('decision','Pending') if ctx else 'Pending'
    review_required = decision != 'Approved'
    return [
        {'step':'01','name':'Document Intelligence','status':'Completed','detail':'Document type, OCR fields, quality and tamper checks completed.'},
        {'step':'02','name':'Identity Verification','status':'Completed','detail':'Name, DOB, address, photo and selfie consistency reviewed.'},
        {'step':'03','name':'Data Protection','status':'Completed','detail':'Sensitive fields are protected for operational display.'},
        {'step':'04','name':'AML / Sanctions / PEP','status':'Completed','detail':'Watchlist, PEP and adverse media screening completed.'},
        {'step':'05','name':'Risk Intelligence','status':'Completed','detail':'Risk score and queue priority generated.'},
        {'step':'06','name':'Human Review','status':'Ready' if review_required else 'Not Required','detail':'Maker-checker review is available for exception cases.'},
        {'step':'07','name':'Decision & Notification','status':'Completed','detail':'Final decision explanation and notification summary prepared.'},
        {'step':'08','name':'Audit Governance','status':'Completed','detail':'Evidence pack and trace-ready audit record available.'},
    ]

def build_audit_timeline(ctx):
    cust = ctx.get('cust', {}) if ctx else {}
    decision = ctx.get('decision','Pending') if ctx else 'Pending'
    docs = len(ctx.get('files', []) or []) if ctx else 0
    return [
        {'time': cust.get('application_date','Today'), 'event': 'Customer registered', 'detail': f"Case {cust.get('case_id','')} created through {cust.get('application_channel','Portal')}"},
        {'time': 'System', 'event': 'Documents received', 'detail': f'{docs} evidence file(s) available in document locker'},
        {'time': 'AI Engine', 'event': 'Agent review completed', 'detail': '13-agent workflow generated document, identity, compliance, risk and decision outputs'},
        {'time': 'Decision Engine', 'event': f'Decision: {decision}', 'detail': build_decision_explanation(ctx)['reason']},
        {'time': 'Audit', 'event': 'Evidence pack ready', 'detail': 'Trace log, reviewer action and final status are audit-ready'},
    ]

def build_notification_items(ctx):
    exp = build_decision_explanation(ctx)
    return [
        {'title':'Application received', 'body':'Your KYC application has been received and assigned to TrustShield AI.'},
        {'title':'Documents processed', 'body':f"{exp['documents']} document evidence record(s) are available for verification."},
        {'title':'AI verification completed', 'body':f"Decision: {exp['decision']}. Risk score: {exp['risk_score']}/100."},
        {'title':'Next action', 'body':exp['action']},
    ]

def build_reupload_options(ctx):
    base = ['PAN card unclear', 'Aadhaar/utility bill mismatch', 'Bank statement missing or unreadable', 'Salary slip missing or unreadable', 'Selfie/photo not clear']
    issues = ctx.get('issues', []) if ctx else []
    return base + [str(i)[:90] for i in issues[:3]]


def customer_screening_summary(cid):
    d=load_data(); cid=str(cid)
    out={'sanctions':False,'pep':False,'fraud':False,'adverse':False,'notes':[]}
    s=d['sanctions']; p=d['pep']; f=d['fraud']; a=d['adverse']
    if not s.empty:
        r=s[s['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('sanctions_match',0) or 0)==1:
            out['sanctions']=True; out['notes'].append('Sanctions list match flagged')
        if not r.empty and int(r.iloc[0].get('high_risk_country',0) or 0)==1:
            out['notes'].append('High-risk country flagged')
    if not p.empty:
        r=p[p['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('pep_match',0) or 0)==1:
            out['pep']=True; out['notes'].append('PEP match flagged')
    if not f.empty:
        r=f[f['customer_id'].astype(str)==cid]
        if not r.empty:
            row=r.iloc[0]
            flags=[c for c in ['duplicate_mobile','duplicate_pan','duplicate_bank_account','repeated_kyc_attempt','synthetic_identity_signal'] if int(row.get(c,0) or 0)==1]
            if flags:
                out['fraud']=True; out['notes'].append('Fraud signal(s): '+', '.join(flags))
    if not a.empty:
        r=a[a['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('adverse_media_match',0) or 0)==1:
            out['adverse']=True; out['notes'].append('Adverse media match flagged')
    return out

def _rel_clean(rel_path):
    return str(rel_path or '').strip().lstrip('/').replace('\\','/')

def _evidence_fallback_path(rel_path):
    """No customer profile is mapped to bundled evidence packages.
    Existing portfolio customers without uploaded photos use the neutral placeholder.
    New applications display only their own uploaded/imported evidence."""
    return None

def asset_exists(rel_path):
    rel = _rel_clean(rel_path)
    if not rel:
        return False
    if (BASE/rel).exists():
        return True
    fb = _evidence_fallback_path(rel)
    return bool(fb and (BASE/fb).exists())

def media_url(rel_path, kind='document'):
    """Return image as inline data URI so AMD/Jupyter proxy cannot block photos.
    Includes a evidence fallback so all synthetic customers display a professional avatar/evidence preview."""
    try:
        rel = _rel_clean(rel_path)
        full = BASE / rel if rel else None
        if not full or not full.exists():
            fb = _evidence_fallback_path(rel)
            full = BASE / fb if fb else None
        if full and full.exists() and full.is_file():
            mime = mimetypes.guess_type(str(full))[0] or 'image/png'
            if kind == 'avatar' and not str(mime).startswith('image/'):
                return inline_static_svg('avatar_placeholder.svg')
            if kind == 'document' and not str(mime).startswith('image/'):
                return inline_static_svg('document_placeholder.svg')
            data = base64.b64encode(full.read_bytes()).decode('ascii')
            return f'data:{mime};base64,{data}'
    except Exception:
        pass
    if kind == 'avatar':
        return inline_static_svg('avatar_placeholder.svg')
    return inline_static_svg('document_placeholder.svg')

def inline_static_svg(filename):
    try:
        full = BASE / 'frontend' / 'static' / 'img' / filename
        data = base64.b64encode(full.read_bytes()).decode('ascii')
        return f'data:image/svg+xml;base64,{data}'
    except Exception:
        return ''

def queue_df(status=None):
    c=load_data()['customers'].copy()
    if c.empty: return c
    c['normalized_status']=c['case_status'].apply(normalize_status)
    if status and status!='All': c=c[c['normalized_status']==status]
    return c


def evidence_counts_by_customer():
    """Return uploaded evidence counts per customer from the document registry.
    Full evidence = at least 5 KYC documents plus photo/selfie entries when available."""
    files = read_csv('document_file_registry.csv')
    counts = {}
    if files.empty or 'customer_id' not in files.columns:
        return counts
    for cid, grp in files.groupby(files['customer_id'].astype(str)):
        doc_types = {clean_value(x) for x in grp.get('document_type', pd.Series(dtype=str)).tolist()}
        kyc_docs = {x for x in doc_types if x not in ('Customer Photo','Selfie / Photo','Selfie','Profile Photo','')}
        counts[str(cid)] = {
            'total_files': int(len(grp)),
            'kyc_docs': int(len(kyc_docs)),
            'has_photo': any(x in doc_types for x in ('Customer Photo','Profile Photo')),
            'has_selfie': any(x in doc_types for x in ('Selfie / Photo','Selfie')),
        }
    return counts

def evidence_status_for_customer(customer_id, counts=None):
    counts = counts if counts is not None else evidence_counts_by_customer()
    rec = counts.get(str(customer_id), {'total_files':0,'kyc_docs':0,'has_photo':False,'has_selfie':False})
    if rec.get('kyc_docs',0) >= 5 and rec.get('has_photo') and rec.get('has_selfie'):
        return 'Evidence Available', 'b-approved', rec.get('kyc_docs',0)
    if rec.get('total_files',0) > 0:
        return 'Partial Evidence', 'b-pending', rec.get('kyc_docs',0)
    return 'Evidence Pending', 'b-neutral', 0

def build_queue_url(status='All', q='', evidence='All', risk='All', per_page=10, page=1):
    params = {'status': status, 'q': q, 'evidence': evidence, 'risk': risk, 'per_page': per_page, 'page': page}
    params = {k:v for k,v in params.items() if str(v) not in ('', 'None')}
    return '/staff/queue?' + urlencode(params)

def metrics():
    c=queue_df()
    if c.empty: return {}
    return {
        'total': len(c),
        'approved': int((c['normalized_status']=='Approved').sum()),
        'review': int((c['normalized_status']=='Manual Review Required').sum()),
        'docs': int((c['normalized_status']=='More Documents Required').sum()),
        'rejected': int((c['normalized_status']=='Rejected').sum()),
        'high': int(c['synthetic_risk_profile'].astype(str).str.contains('High|Critical',case=False,na=False).sum()) if 'synthetic_risk_profile' in c else 0,
    }

templates.env.filters['badge'] = status_badge
templates.env.filters['mask_pii'] = mask_pii_value


def ops_insights():
    c=queue_df()
    m=metrics()
    total=max(m.get('total',0),1)
    dist=[
        {'label':'Approved','count':m.get('approved',0),'pct':round(m.get('approved',0)*100/total),'url':'/staff/queue?status=Approved','class':'ok'},
        {'label':'Manual Review','count':m.get('review',0),'pct':round(m.get('review',0)*100/total),'url':'/staff/queue?status=Manual Review Required','class':'warn'},
        {'label':'Document Remediation','count':m.get('docs',0),'pct':round(m.get('docs',0)*100/total),'url':'/staff/queue?status=More Documents Required','class':'info'},
        {'label':'Rejected / Escalated','count':m.get('rejected',0),'pct':round(m.get('rejected',0)*100/total),'url':'/staff/queue?status=Rejected','class':'bad'},
    ]
    if c.empty:
        return {'dist':dist,'channels':[],'states':[],'breach':0,'approval_rate':0}
    channels=[]
    if 'application_channel' in c.columns:
        for k,v in c['application_channel'].fillna('Unknown').value_counts().head(5).items():
            channels.append({'name':k,'count':int(v),'pct':round(int(v)*100/len(c))})
    states=[]
    if 'state' in c.columns:
        for k,v in c['state'].fillna('Unknown').value_counts().head(5).items():
            states.append({'name':k,'count':int(v),'pct':round(int(v)*100/len(c))})
    breach=int((pd.to_numeric(c.get('sla_hours',0), errors='coerce').fillna(0) <= 24).sum()) if 'sla_hours' in c else 0
    approval_rate=round(m.get('approved',0)*100/total)
    return {'dist':dist,'channels':channels,'states':states,'breach':breach,'approval_rate':approval_rate}

def row_priority(row):
    """Return business-friendly case priority labels only: Critical, High, Medium, Low."""
    txt = (str(row.get('synthetic_risk_profile','')) + ' ' + str(row.get('case_status',''))).lower()
    if 'critical' in txt or 'reject' in txt or 'escalat' in txt:
        return 'Critical'
    if 'high' in txt or 'manual review' in txt or 'review' in txt:
        return 'High'
    if 'document' in txt or 'pending' in txt or 're-upload' in txt or 'remediation' in txt:
        return 'Medium'
    return 'Low'

def enrich_rows(records):
    counts = evidence_counts_by_customer()
    out=[]
    for r in records:
        r=dict(r)
        r['priority']=row_priority(r)
        st=normalize_status(r.get('case_status',''))
        if st=='Approved': r['stage']='Completed'
        elif st=='Manual Review Required': r['stage']='Human Review'
        elif st=='More Documents Required': r['stage']='Remediation'
        elif st=='Rejected': r['stage']='Closed - Rejected'
        else: r['stage']='Intake'
        ev_label, ev_class, doc_count = evidence_status_for_customer(r.get('customer_id',''), counts)
        r['evidence_status'] = ev_label
        r['evidence_class'] = ev_class
        r['evidence_doc_count'] = doc_count
        out.append(r)
    return out

templates.env.filters['priority'] = row_priority


AGENT_CATALOG = [
    {
        'id':'document_intelligence',
        'name':'Document Intelligence Agent',
        'stage':'Data Extraction',
        'purpose':'Reads uploaded KYC documents, extracts name, DOB, address, ID numbers and validates document quality.',
        'inputs':'PAN, Aadhaar, passport, bank statement, salary slip, utility bill, selfie',
        'checks':['OCR field extraction','Document type classification','Blur/quality validation','Tamper indicator check'],
        'output':'Structured document fields and document quality score',
        'icon':'📄'
    },
    {
        'id':'identity_verification',
        'name':'Identity Verification Agent',
        'stage':'Identity Resolution',
        'purpose':'Compares customer profile details against document fields and selfie/photo evidence.',
        'inputs':'Customer profile, document photo, selfie, extracted fields',
        'checks':['Name match','DOB match','Address match','Face/selfie confidence','Duplicate identity signal'],
        'output':'Identity match score and mismatch evidence',
        'icon':'🧑‍💼'
    },
    {
        'id':'compliance_screening',
        'name':'Compliance Screening Agent',
        'stage':'AML / Watchlist Screening',
        'purpose':'Screens customer against sanctions, PEP, adverse media and fraud references.',
        'inputs':'Name, DOB, address, nationality, transaction profile',
        'checks':['Sanctions screening','PEP screening','Adverse media scan','Watchlist lookup'],
        'output':'Compliance alert summary and screening disposition',
        'icon':'🛡️'
    },
    {
        'id':'financial_profile',
        'name':'Financial Profiling Agent',
        'stage':'Financial Due Diligence',
        'purpose':'Checks declared income, occupation, bank statement consistency and transaction behavior.',
        'inputs':'Income range, occupation, bank statement, transactions',
        'checks':['Income consistency','Average balance review','Transaction anomaly scan','Customer segment validation'],
        'output':'Financial risk profile and anomaly flags',
        'icon':'💳'
    },
    {
        'id':'fraud_intelligence',
        'name':'Fraud Intelligence Agent',
        'stage':'Fraud Detection',
        'purpose':'Detects forged documents, duplicate submissions, suspicious identity behavior and photo mismatch risk.',
        'inputs':'Document metadata, photo, selfie, device/channel signals',
        'checks':['Tampering indicator','Photo mismatch','Duplicate customer pattern','High-risk channel signal'],
        'output':'Fraud score and evidence flags',
        'icon':'🚨'
    },
    {
        'id':'risk_intelligence',
        'name':'Risk Intelligence Agent',
        'stage':'Risk Scoring',
        'purpose':'Combines all agent outputs and assigns explainable customer risk and target queue.',
        'inputs':'Document, identity, compliance, financial and fraud outputs',
        'checks':['Risk profile calculation','SLA priority','Queue assignment','Policy control matching'],
        'output':'Low/Medium/High/Critical risk and routing recommendation',
        'icon':'📊'
    },
    {
        'id':'decision_reasoning',
        'name':'Decision Reasoning Agent',
        'stage':'Explainable Decision',
        'purpose':'Creates the final KYC decision with explanation and evidence pack for audit.',
        'inputs':'All verification outputs, profile signals and document status',
        'checks':['Profile evidence review','Identity confidence review','Document completeness review','Risk disposition review'],
        'output':'Approve / Manual Review / More Documents Required / Reject with reason',
        'icon':'🧠'
    },
    {
        'id':'human_review',
        'name':'Human Review Agent',
        'stage':'Human-in-the-loop',
        'purpose':'Routes exception cases to staff, supports maker-checker review and captures reviewer decisions.',
        'inputs':'Case evidence, AI recommendation, reviewer notes',
        'checks':['Manual queue routing','Reviewer action capture','Manager escalation','Audit trail update'],
        'output':'Staff decision, escalation or closure action',
        'icon':'👥'
    },
    {
        'id':'notification_audit',
        'name':'Notification & Audit Agent',
        'stage':'Communication & Governance',
        'purpose':'Generates customer/staff notifications and maintains evidence, trace logs and audit records.',
        'inputs':'Decision output, case status, reviewer actions',
        'checks':['Customer notification','Staff notification','Evidence pack','Decision trace log'],
        'output':'Email/message content and auditable evidence trail',
        'icon':'✉️'
    },
]

def _safe_int(v, default=0):
    try:
        return int(float(v))
    except Exception:
        return default


def _screening_hits_for_ctx(ctx):
    cust = (ctx or {}).get('cust', {})
    try:
        sc = customer_screening_summary(cust.get('customer_id'))
    except Exception:
        sc = {'sanctions':0,'pep':0,'fraud':0,'adverse':0}
    return {
        'sanctions': _safe_int(sc.get('sanctions')),
        'pep': _safe_int(sc.get('pep')),
        'fraud': _safe_int(sc.get('fraud')),
        'adverse_media': _safe_int(sc.get('adverse')),
        'total': _safe_int(sc.get('sanctions')) + _safe_int(sc.get('pep')) + _safe_int(sc.get('fraud')) + _safe_int(sc.get('adverse')),
    }


def build_agent_power_profile(ctx):
    """Enterprise agent intelligence snapshot used by all verification agents."""
    ctx = ctx or {}
    cust = ctx.get('cust', {})
    docs = ctx.get('docs', []) or []
    files = ctx.get('files', []) or []
    rows = ctx.get('discrepancy_rows') or build_discrepancy_rows(ctx)
    valid_bad = [r for r in rows if r.get('class') == 'bad']
    review_rows = [r for r in rows if r.get('class') == 'warn']
    extraction_pending = ctx.get('extraction_pending', []) or []
    cross_issues = ctx.get('cross_check_issues', []) or []
    consistency_issues = ctx.get('document_consistency_issues', []) or []
    matching = ctx.get('matching_scores') or build_matching_scores(ctx)
    face = ctx.get('face_match') or build_face_match(ctx)
    screening = _screening_hits_for_ctx(ctx)
    mandatory_types = {'PAN','Aadhaar','Bank Statement','Salary Slip','Utility Bill'}
    present = {clean_value(d.get('document_type','')) for d in docs}
    missing = sorted(mandatory_types - present)
    tamper_count = sum(1 for d in docs if clean_value(d.get('tampering_indicator'),'Not Detected').lower() != 'not detected')
    quality_review = sum(1 for d in docs if clean_value(d.get('quality_status'),'Passed').lower() != 'passed')
    critical = bool(ctx.get('critical_identity_mismatch')) or screening['sanctions'] > 0
    if critical or len(valid_bad) > 2:
        recommended = 'Rejected / Escalated'
    elif missing or extraction_pending or review_rows or len(valid_bad) > 0:
        recommended = 'Manual Review Required'
    else:
        recommended = 'Approved'
    risk_score = (ctx.get('decision_explanation') or build_decision_explanation(ctx)).get('risk_score', 80)
    if risk_score < 45 or critical:
        risk_band = 'Critical'
    elif risk_score < 65 or len(valid_bad) > 1:
        risk_band = 'High'
    elif risk_score < 80 or review_rows:
        risk_band = 'Medium'
    else:
        risk_band = 'Low'
    return {
        'case_id': cust.get('case_id',''),
        'customer_id': cust.get('customer_id',''),
        'document_count': len(docs),
        'file_count': len(files),
        'present_documents': sorted(present),
        'missing_documents': missing,
        'valid_mismatch_count': len(valid_bad),
        'review_signal_count': len(review_rows),
        'extraction_pending_count': len(extraction_pending),
        'cross_document_issue_count': len(consistency_issues),
        'cross_profile_issue_count': len(cross_issues),
        'tamper_count': tamper_count,
        'quality_review_count': quality_review,
        'identity_score': matching.get('overall', 0),
        'name_score': matching.get('name', 0),
        'dob_score': matching.get('dob', 0),
        'address_score': matching.get('address', 0),
        'face_score': face.get('score', 0),
        'face_result': face.get('result',''),
        'screening': screening,
        'risk_score': risk_score,
        'risk_band': risk_band,
        'critical': critical,
        'recommended_status': recommended,
        'top_findings': (cross_issues + consistency_issues + extraction_pending + [r.get('reason','') for r in valid_bad + review_rows])[:8],
    }


def _agent_result(agent, status='Completed', confidence=90, finding='', evidence=None, controls=None, recommendation=''):
    evidence = evidence or []
    controls = controls or []
    return {
        **agent,
        'status': status,
        'confidence': int(max(1, min(99, confidence))),
        'finding': finding or 'Verification checks completed.',
        'evidence': evidence[:8],
        'controls': controls[:6],
        'recommendation': recommendation,
    }


def agent_run_for_case(ctx):
    """Run the full 13-agent KYC workflow with stronger, evidence-led outputs."""
    if not ctx:
        return []
    cust = ctx['cust']
    power = build_agent_power_profile(ctx)
    decision = ctx.get('decision') or cust.get('case_status','Pending')
    results = []
    for agent in AGENT_CATALOG:
        aid = agent['id']
        status = 'Completed'
        if aid == 'document_intelligence':
            confidence = 97 - (power['extraction_pending_count'] * 10) - (power['quality_review_count'] * 8) - (power['tamper_count'] * 18)
            finding = f"{power['document_count']} KYC document record(s) processed; {power['extraction_pending_count']} extraction item(s) need review."
            evidence = [
                f"Detected documents: {', '.join(power['present_documents']) or 'Pending'}",
                f"Missing mandatory evidence: {', '.join(power['missing_documents']) if power['missing_documents'] else 'None'}",
                f"Quality review flags: {power['quality_review_count']}",
                f"Tamper indicators: {power['tamper_count']}",
            ]
            controls = ['Document classification', 'Field extraction', 'Quality validation', 'Tamper signal review']
            rec = 'Request clearer document or manual extraction review.' if power['extraction_pending_count'] else 'Continue identity comparison.'
        elif aid == 'identity_verification':
            confidence = power['identity_score'] - (power['valid_mismatch_count'] * 12)
            finding = f"Identity score {power['identity_score']}%; name {power['name_score']}%, DOB {power['dob_score']}%, address {power['address_score']}%, face {power['face_score']}%."
            evidence = [
                f"Profile-to-document issues: {power['cross_profile_issue_count']}",
                f"Document-to-document issues: {power['cross_document_issue_count']}",
                f"Face result: {power['face_result']}",
            ] + power['top_findings'][:4]
            controls = ['Profile vs evidence match', 'Document-to-document consistency', 'Face evidence check', 'Duplicate identity signal']
            rec = 'Reject or escalate identity mismatch.' if power['critical'] or power['valid_mismatch_count'] > 2 else ('Send to reviewer.' if power['valid_mismatch_count'] or power['extraction_pending_count'] else 'Identity verified.')
        elif aid == 'selective_pii_masking':
            confidence = 96
            finding = 'Sensitive contact and identity fields are protected in operational screens and audit exports.'
            evidence = ['Email and mobile protected', 'ID numbers protected', 'Address minimized where possible', 'Raw evidence retained only in evidence viewer']
            controls = ['Display masking', 'Audit-safe output', 'Need-to-know evidence access']
            rec = 'PII controls active.'
        elif aid == 'compliance_rag':
            confidence = 94 - len(power['missing_documents']) * 5
            finding = 'KYC controls checked against mandatory evidence, identity consistency and review routing requirements.'
            evidence = ['Mandatory identity document control applied', 'Address proof and financial evidence control applied', f"Missing evidence count: {len(power['missing_documents'])}", f"Recommended queue: {power['recommended_status']}"]
            controls = ['Mandatory document policy', 'Maker-checker requirement', 'Evidence retention control', 'Exception handling control']
            rec = 'Complete missing evidence before closure.' if power['missing_documents'] else 'Policy controls satisfied or routed.'
        elif aid == 'aml_sanctions':
            hits = power['screening']
            confidence = 92 if hits['sanctions'] == 0 and hits['pep'] == 0 else 67
            finding = f"Sanctions hits: {hits['sanctions']}; PEP hits: {hits['pep']}."
            evidence = ['Sanctions watchlist checked', 'PEP list checked', 'Name and DOB screening performed']
            controls = ['Sanctions disposition', 'PEP review', 'False-positive handling']
            rec = 'Escalate to compliance.' if hits['sanctions'] or hits['pep'] else 'No AML escalation from current data.'
        elif aid == 'adverse_media':
            hits = power['screening']
            confidence = 91 if hits['adverse_media'] == 0 else 70
            finding = f"Adverse media indicators: {hits['adverse_media']}."
            evidence = ['Adverse media dataset checked', 'Financial-crime indicators reviewed', 'Reviewer note prepared']
            controls = ['Media-risk screening', 'Risk-tag summary', 'Entity ambiguity handling']
            rec = 'Reviewer should validate adverse-media hit.' if hits['adverse_media'] else 'No adverse-media issue from current data.'
        elif aid == 'financial_profiling':
            confidence = 88
            income = clean_value(cust.get('income_range'), 'Not declared')
            occupation = clean_value(cust.get('occupation'), 'Not declared')
            finding = f"Declared occupation/income reviewed: {occupation} / {income}."
            evidence = ['Income declaration reviewed', 'Bank statement presence checked', 'Salary slip presence checked', 'Financial profile consistency assessed']
            controls = ['Income plausibility', 'Bank evidence review', 'Salary evidence review']
            rec = 'Request bank/salary document if unavailable.' if {'Bank Statement','Salary Slip'} - set(power['present_documents']) else 'Financial evidence available.'
        elif aid == 'fraud_intelligence':
            hits = power['screening']
            confidence = 95 - power['tamper_count'] * 25 - power['valid_mismatch_count'] * 10 - hits['fraud'] * 25
            finding = f"Fraud signals: tamper {power['tamper_count']}, identity mismatch {power['valid_mismatch_count']}, watchlist fraud {hits['fraud']}."
            evidence = ['Tamper indicator reviewed', 'Duplicate / synthetic identity signal checked', 'Photo mismatch risk considered'] + power['top_findings'][:3]
            controls = ['Tamper review', 'Duplicate identity review', 'Synthetic identity signal', 'File reuse detection']
            rec = 'Reject or escalate fraud risk.' if power['critical'] or power['tamper_count'] or hits['fraud'] else 'No major fraud signal from current data.'
        elif aid == 'risk_intelligence':
            confidence = 92 - power['valid_mismatch_count'] * 6 - power['screening']['total'] * 10
            finding = f"Risk band {power['risk_band']} with score {power['risk_score']}/100; target outcome {power['recommended_status']}."
            evidence = [f"Identity score: {power['identity_score']}%", f"Valid mismatch count: {power['valid_mismatch_count']}", f"Screening hits: {power['screening']['total']}", f"Pending extraction: {power['extraction_pending_count']}"]
            controls = ['Risk score weighting', 'Queue routing', 'SLA priority', 'Exception threshold']
            rec = power['recommended_status']
        elif aid == 'decision_reasoning':
            confidence = 94 if decision == power['recommended_status'] or str(decision) in str(power['recommended_status']) else 86
            finding = f"Current decision '{decision}' evaluated against agent recommendation '{power['recommended_status']}'."
            evidence = ['Evidence completeness reviewed', 'Identity mismatch count reviewed', 'Screening alerts reviewed', 'Staff override path available']
            controls = ['Explainable decision', 'Exception routing', 'Staff override audit', 'Evidence pack readiness']
            rec = power['recommended_status']
        elif aid == 'human_review':
            needs_review = power['recommended_status'] != 'Approved'
            confidence = 86
            status = 'Ready' if needs_review else 'Not Required'
            finding = 'Human review is ready for exceptions, overrides and evidence notes.' if needs_review else 'No manual review required unless staff chooses override.'
            evidence = ['Approve / reject / re-upload actions available', 'Reviewer reason captured', 'Manager escalation supported']
            controls = ['Maker-checker action', 'Reason capture', 'Override audit']
            rec = 'Reviewer should validate exceptions.' if needs_review else 'Straight-through closure is available.'
        elif aid == 'notification_email':
            confidence = 96
            finding = 'Customer and staff notification content prepared for the latest case outcome.'
            evidence = ['Approval notification', 'Re-upload request', 'Review assignment', 'Closure message']
            controls = ['Customer communication', 'Staff queue alert', 'Message audit']
            rec = 'Send status communication after staff action.'
        elif aid == 'audit_governance':
            confidence = 97
            finding = 'Trace, PDF evidence pack and decision history are ready for audit review.'
            evidence = ['Agent trace JSON', 'Evidence PDF', 'Document preview links', 'Reviewer action trail']
            controls = ['Evidence retention', 'Traceability', 'Decision history', 'Governance review']
            rec = 'Evidence pack can be downloaded after review.'
        else:
            confidence = 90
            finding = 'Verification control completed.'
            evidence = ['Control output available']
            controls = ['Operational control']
            rec = 'Continue workflow.'
        results.append(_agent_result(agent, status, confidence, finding, evidence, controls, rec))
    return results



# Extra agents from the original TrustShield workflow so the FastAPI app preserves the full AGENTS_002 concept.
AGENT_CATALOG += [
    {
        'id':'data_protection', 'name':'Data Protection Service', 'stage':'Information Protection',
        'purpose':'Protects sensitive customer fields before operational display, logs or evidence sharing while keeping required review fields usable.',
        'inputs':'Name, mobile, email, address, ID numbers, uploaded document fields',
        'checks':['Protect ID numbers','Protect email/mobile in staff views','Protect raw document values','Preserve audit-safe evidence'],
        'output':'Protected customer and document view', 'icon':'🔐'
    },
    {
        'id':'compliance_rag', 'name':'Compliance RAG Agent', 'stage':'Policy Retrieval',
        'purpose':'Retrieves KYC policy controls and applies them to decision explanation, remediation, escalation and evidence pack creation.',
        'inputs':'KYC policy knowledge base, document controls, discrepancy count, risk profile',
        'checks':['Policy control retrieval','Mandatory document policy','Review threshold control','Explainable control mapping'],
        'output':'Policy-backed decision rationale', 'icon':'📚'
    },
    {
        'id':'aml_sanctions', 'name':'AML & Sanctions Screening Agent', 'stage':'Regulatory Screening',
        'purpose':'Checks sanctions, PEP and AML risk signals and routes cases to compliance if a potential hit is found.',
        'inputs':'Customer identity, nationality, address, watchlists and screening references',
        'checks':['AML risk scan','Sanctions screening','PEP screening','False-positive handling'],
        'output':'AML/PEP/sanctions disposition', 'icon':'🌐'
    },
    {
        'id':'adverse_media', 'name':'Adverse Media Intelligence Agent', 'stage':'Reputation Screening',
        'purpose':'Finds and summarizes adverse news/media risk indicators and adds explainable signals to the risk score.',
        'inputs':'Customer/entity name, city, adverse media dataset, risk tags',
        'checks':['Adverse media hit check','Risk category tagging','Entity ambiguity handling','Reviewer evidence note'],
        'output':'Adverse media risk summary', 'icon':'📰'
    },

    {
        'id':'notification_email', 'name':'Notification & Email Agent', 'stage':'Customer Communication',
        'purpose':'Creates customer and staff email notifications for approval, re-upload request, manual review, rejection and escalation updates.',
        'inputs':'Decision output, case status, discrepancy reason, customer contact, staff queue',
        'checks':['Customer approval email','Re-upload request email','Staff queue notification','Escalation alert'],
        'output':'Secure email and notification content', 'icon':'📨'
    },
    {
        'id':'audit_governance', 'name':'Audit & Governance Agent', 'stage':'Governance',
        'purpose':'Creates traceable audit logs, evidence packs and decision history for regulatory review.',
        'inputs':'All agent outputs, reviewer decisions, notification actions and case status changes',
        'checks':['Trace file generation','Evidence pack readiness','Reviewer note capture','Decision immutability check'],
        'output':'Audit trail and governance evidence', 'icon':'🧾'
    }
]


# Final enterprise workflow catalog: exactly 13 specialized KYC agents.
AGENT_CATALOG = [
    {'id':'document_intelligence','name':'Document Intelligence Agent','stage':'Document Understanding','purpose':'Classifies uploaded files, extracts document owner fields, validates quality and prepares structured evidence.','inputs':'Uploaded PAN, Aadhaar, utility bill, bank statement, salary slip, selfie and profile photo','checks':['Document type classification','Name/DOB/address extraction','ID number extraction','Quality and tamper signals'],'output':'Structured document evidence','icon':'📄'},
    {'id':'identity_verification','name':'Identity Verification Agent','stage':'Identity Resolution','purpose':'Compares registration details with every document and also cross-checks documents against one another.','inputs':'Registration profile, extracted document fields, selfie/photo evidence','checks':['Registration vs document match','Document-to-document consistency','Face evidence confidence','Critical mismatch routing'],'output':'Identity confidence and mismatch summary','icon':'🧑‍💼'},
    {'id':'selective_pii_masking','name':'Selective PII Masking Agent','stage':'Data Protection','purpose':'Protects sensitive fields in screens, summaries, logs and evidence views while preserving review usability.','inputs':'Email, mobile, address, ID numbers and extracted document fields','checks':['Email masking','Mobile masking','ID masking','Audit-safe display'],'output':'Protected operational view','icon':'🔐'},
    {'id':'compliance_rag','name':'Compliance RAG Agent','stage':'Policy Controls','purpose':'Applies KYC control guidance to mandatory evidence, exception routing and closure readiness.','inputs':'KYC policy controls, document set, review signals, risk profile','checks':['Mandatory evidence policy','Exception routing policy','Evidence retention policy','Review readiness'],'output':'Policy-backed control summary','icon':'📚'},
    {'id':'aml_sanctions','name':'AML & Sanctions Screening Agent','stage':'Regulatory Screening','purpose':'Screens customer identity against sanctions and PEP signals and prepares compliance disposition.','inputs':'Name, DOB, address, nationality and watchlist datasets','checks':['Sanctions screening','PEP screening','False-positive handling','Compliance escalation'],'output':'AML and sanctions disposition','icon':'🌐'},
    {'id':'adverse_media','name':'Adverse Media Intelligence Agent','stage':'Reputation Screening','purpose':'Checks adverse media indicators and adds explainable risk signals to the case file.','inputs':'Customer identity, city, adverse media references and risk tags','checks':['Adverse media hit check','Risk category tagging','Entity ambiguity handling','Reviewer note creation'],'output':'Adverse media summary','icon':'📰'},
    {'id':'financial_profiling','name':'Financial Profiling Agent','stage':'Financial Due Diligence','purpose':'Reviews declared occupation, income range, bank evidence and salary evidence for consistency.','inputs':'Occupation, income range, bank statement, salary slip and transaction summary','checks':['Income consistency','Bank evidence presence','Salary evidence presence','Financial anomaly indicator'],'output':'Financial risk profile','icon':'💳'},
    {'id':'fraud_intelligence','name':'Fraud Intelligence Agent','stage':'Fraud Detection','purpose':'Detects identity mismatch, tamper signals, duplicate or synthetic identity risk and suspicious evidence patterns.','inputs':'Document metadata, extracted fields, photo evidence, watchlist fraud signals','checks':['Identity mismatch severity','Tamper signal','Synthetic identity signal','Document reuse indicator'],'output':'Fraud risk summary','icon':'🚨'},
    {'id':'risk_intelligence','name':'Risk Intelligence Agent','stage':'Risk Scoring','purpose':'Combines all verification outputs into a risk score, risk band and queue recommendation.','inputs':'Document, identity, compliance, financial and fraud outputs','checks':['Risk score weighting','Queue routing','SLA priority','Exception threshold'],'output':'Risk band and routing recommendation','icon':'📊'},
    {'id':'decision_reasoning','name':'Decision Reasoning Agent','stage':'Decision Intelligence','purpose':'Creates explainable KYC outcome from evidence completeness, identity confidence, screening and fraud signals.','inputs':'All agent outputs and reviewer status','checks':['Approval readiness','Manual review routing','Re-upload need','Reject/escalate threshold'],'output':'Explainable decision recommendation','icon':'🧠'},
    {'id':'human_review','name':'Human Review Agent','stage':'Staff Review','purpose':'Supports staff approval, rejection, re-upload request and override with reason capture.','inputs':'Case evidence, AI recommendation and reviewer notes','checks':['Reviewer action capture','Reason capture','Manager escalation','Override audit'],'output':'Staff action and audit update','icon':'👥'},
    {'id':'notification_email','name':'Notification & Email Agent','stage':'Communication','purpose':'Prepares customer and staff communications for approval, review, re-upload and closure.','inputs':'Decision output, case status, reviewer actions and customer contact','checks':['Customer status message','Staff alert','Re-upload instruction','Closure communication'],'output':'Notification content','icon':'📨'},
    {'id':'audit_governance','name':'Audit & Governance Agent','stage':'Governance','purpose':'Creates trace files, evidence packs and decision history for audit and compliance review.','inputs':'Agent outputs, reviewer decisions, document previews and final status','checks':['Trace file generation','PDF evidence pack','Decision history','Evidence retention'],'output':'Audit-ready evidence trail','icon':'🧾'},
]

# Compatibility routes for notebook/proxy tools that still check Streamlit-style endpoints.
# This app is FastAPI, so these endpoints are not used by the UI, but returning 200 avoids confusing 404 logs.
@app.get('/_stcore/health')
def streamlit_health_compat():
    return {'status': 'ok', 'app': 'TrustShield FastAPI'}

@app.get('/_stcore/host-config')
def streamlit_host_config_compat():
    return {'server': 'fastapi', 'websocketCompression': False}

@app.get('/favicon.ico')
def favicon():
    return JSONResponse({}, status_code=204)

@app.get('/api/health')
def api_health(request: Request):
    return {
        'status':'ok',
        'app':'TrustShield KYC',
        'version':'v14',
        'customers': metrics().get('total',0),
        'gemini': 'Connected' if gemini_key_configured() else 'Not Connected',
        'email_notification_service':'Active',
        'agent_workflow':'Ready',
        'pdf_evidence_service':'Available',
    }


@app.get('/')
def root(request: Request):
    user=get_user(request)
    if user: return redirect(request, role_home(user['role']))
    return templates.TemplateResponse(request, 'login.html', {'request':request,'user':None})


@app.get('/forgot-password')
def forgot_password_page(request: Request):
    return templates.TemplateResponse(request, 'forgot_password.html', {'request': request, 'user': None, 'submitted': False})

@app.post('/forgot-password')
def forgot_password_submit(request: Request, identifier: str=Form(...)):
    out = BASE / 'outputs' / 'password_reset_requests.log'
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} | RESET_REQUEST | {identifier}\n")
    return templates.TemplateResponse(request, 'forgot_password.html', {'request': request, 'user': None, 'submitted': True})

@app.post('/login')
def login(request: Request, username: str=Form(...), password: str=Form(...)):
    u=username.strip(); p=password.strip()
    staff_user = os.getenv('STAFF_USER_ID', 'staff').lower()
    staff_password = os.getenv('STAFF_PASSWORD', 'Trust@123')
    if u.lower()==staff_user and p==staff_password:
        request.session['user']={'role':'staff','username':'staff','name':'KYC Operations Staff'}
        return redirect(request, '/staff/dashboard')
    cust=get_customer(u)
    if cust and verify_customer_password(cust, p):
        request.session['user']={'role':'customer','username':cust.get('login_username',''),'customer_id':cust['customer_id'],'case_id':cust['case_id'],'name':cust['full_name']}
        return redirect(request, '/customer/dashboard')
    return templates.TemplateResponse(request, 'login.html', {'request':request,'user':None,'error':'Invalid user ID or password.'})

@app.get('/logout')
def logout(request: Request):
    request.session.clear(); return redirect(request, '/')

@app.get('/staff/logout')
def staff_logout_alias(request: Request):
    request.session.clear(); return redirect(request, '/')

@app.get('/customer/logout')
def customer_logout_alias(request: Request):
    request.session.clear(); return redirect(request, '/')

@app.get('/staff/dashboard')
def staff_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    d=load_data(); recent=enrich_rows(queue_df().head(10).to_dict('records'))
    return templates.TemplateResponse(request, 'staff_dashboard.html', {'request':request,'user':user,'active':'dashboard','m':metrics(),'insights':ops_insights(),'recent':recent})

@app.get('/staff/queue')
def staff_queue(request: Request, status: str='All', q: str='', evidence: str='All', risk: str='All', page: int=1, per_page: int=10):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    df=queue_df(status)
    if q:
        ql=q.lower(); df=df[df.apply(lambda r: ql in ' '.join(map(str,r.values)).lower(), axis=1)]
    if risk and risk!='All' and 'synthetic_risk_profile' in df.columns:
        df=df[df['synthetic_risk_profile'].astype(str).str.contains(risk, case=False, na=False)]
    counts = evidence_counts_by_customer()
    if evidence and evidence!='All' and not df.empty:
        labels = df['customer_id'].astype(str).apply(lambda cid: evidence_status_for_customer(cid, counts)[0])
        df = df[labels.eq(evidence).values]
    try:
        per_page = int(per_page)
    except Exception:
        per_page = 10
    if per_page not in (10,25,50): per_page = 10
    total = int(len(df))
    total_pages = max(1, (total + per_page - 1)//per_page)
    try:
        page = int(page)
    except Exception:
        page = 1
    page = max(1, min(page, total_pages))
    start = (page-1)*per_page
    rows=enrich_rows(df.iloc[start:start+per_page].to_dict('records'))
    pagination = {
        'page': page, 'per_page': per_page, 'total': total, 'total_pages': total_pages,
        'start': start + 1 if total else 0, 'end': min(start+per_page, total),
        'first_url': build_queue_url(status,q,evidence,risk,per_page,1),
        'prev_url': build_queue_url(status,q,evidence,risk,per_page,max(1,page-1)),
        'next_url': build_queue_url(status,q,evidence,risk,per_page,min(total_pages,page+1)),
        'last_url': build_queue_url(status,q,evidence,risk,per_page,total_pages),
    }
    return templates.TemplateResponse(request, 'case_queue.html', {
        'request':request,'user':user,'active':'queue','rows':rows,'status':status,'q':q,
        'evidence':evidence,'risk':risk,'per_page':per_page,'pagination':pagination,
        'm':metrics(),'insights':ops_insights()
    })

@app.get('/staff/case/{case_id}')
def case_profile(request: Request, case_id: str, saved: str=''):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id)
    if not ctx: return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'The selected case was not found.'})
    return templates.TemplateResponse(request, 'case_profile.html', {'request':request,'user':user,'active':'profile','insights':ops_insights(),'catalog':AGENT_CATALOG,'agents':agent_run_for_case(ctx),'saved':bool(saved),'screening':customer_screening_summary(ctx['cust']['customer_id']),**ctx})

ACTION_TO_STATUS = {
    'Approve after review': 'Approved',
    'Request document re-upload': 'More Documents Required',
    'Escalate to manager approval': 'Rejected / Escalated',
    'Mark Enhanced Due Diligence': 'Manual Review Required',
    'Reject with reason': 'Rejected',
}

@app.post('/staff/case/{case_id}/action')
def case_action(request: Request, case_id: str, action: str=Form(...), note: str=Form(''), reason: str=Form('')):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')

    p=BASE/'outputs'/'audit_logs'/'staff_actions.log'
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now().isoformat()} | {user['username']} | {case_id} | {action} | {reason} | {note}\n")

    new_status = ACTION_TO_STATUS.get(action)
    if new_status:
        customers = read_csv('customers.csv')
        if not customers.empty:
            mask = customers['case_id'].astype(str).str.upper() == str(case_id).upper()
            if mask.any():
                customers.loc[mask, 'case_status'] = new_status
                customers.to_csv(BASE/'data'/'customers.csv', index=False)

                cid = customers.loc[mask, 'customer_id'].iloc[0]
                hist_path = BASE/'data'/'case_history.csv'
                history = read_csv('case_history.csv')
                entry = {
                    'case_id': case_id.upper(),
                    'customer_id': cid,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'current_status': new_status,
                    'assigned_queue': customers.loc[mask, 'assigned_queue'].iloc[0] if 'assigned_queue' in customers.columns else '',
                    'sla_hours': customers.loc[mask, 'sla_hours'].iloc[0] if 'sla_hours' in customers.columns else '',
                    'escalation_level': 1 if 'Escalat' in new_status else 0,
                    'last_action': f"Staff decision by {user.get('name', user.get('username'))}: {action}"
                            + (f" ({reason})" if reason else "")
                            + (f" — {note}" if note else ""),
                }
                if history.empty:
                    history = pd.DataFrame([entry])
                else:
                    history = pd.concat([history, pd.DataFrame([entry])], ignore_index=True)
                history.to_csv(hist_path, index=False)
                try:
                    append_notification_record(case_id.upper(), 'Customer', customers.loc[mask, 'email'].iloc[0] if 'email' in customers.columns else '', f'KYC status updated: {new_status}', f'Your KYC case {case_id.upper()} has been updated to {new_status}. Please log in to view the latest status.', 'Sent')
                    append_notification_record(case_id.upper(), 'Staff', 'kyc.operations@example.com', f'Staff action recorded: {action}', f'{user.get('name', user.get('username'))} updated {case_id.upper()} to {new_status}.', 'Sent')
                except Exception:
                    pass

    return redirect(request, f'/staff/case/{case_id}?saved=1')

@app.get('/staff/agent-review')
def agent_review(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    agents=agent_run_for_case(ctx)
    return templates.TemplateResponse(request, 'agent_review.html', {'request':request,'user':user,'active':'agent','ctx':ctx,'agents':agents,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/staff/agents')
def agent_command_center(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    agents=agent_run_for_case(ctx)
    return templates.TemplateResponse(request, 'agents_command.html', {'request':request,'user':user,'active':'agent','ctx':ctx,'agents':agents,'catalog':AGENT_CATALOG,'m':metrics(),'insights':ops_insights()})




def create_agent_execution_trace(ctx):
    """Create a deterministic verification run trace for the workbench UI and audit output."""
    agents = agent_run_for_case(ctx)
    case_id = ctx['cust']['case_id']
    now = datetime.now().isoformat(timespec='seconds')
    workflow_steps = []
    for i, a in enumerate(agents, start=1):
        workflow_steps.append({
            'sequence': i,
            'agent_id': a.get('id', f'agent_{i}'),
            'agent_name': a.get('name', 'Verification Service'),
            'stage': a.get('stage', 'Completed'),
            'status': 'Completed',
            'confidence': a.get('confidence', 95),
            'finding': a.get('finding', 'Checks completed successfully.'),
            'evidence': a.get('evidence', []),
            'output': a.get('output',''),
            'timestamp': now,
        })
    trace = {
        'run_id': f"RUN-{case_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        'case_id': case_id,
        'customer_id': ctx['cust']['customer_id'],
        'customer_name': ctx['cust']['full_name'],
        'decision': ctx.get('decision') or ctx['cust'].get('case_status',''),
        'discrepancy_count': ctx.get('discrepancy', 0),
        'risk_profile': ctx['cust'].get('synthetic_risk_profile','N/A'),
        'agent_count': len(workflow_steps),
        'completed_agents': len(workflow_steps),
        'requires_human_review': (ctx.get('decision') != 'Approved'),
        'generated_at': now,
        'workflow': workflow_steps,
    }
    out_dir = BASE/'outputs'/'agent_traces'
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir/f"{trace['run_id']}.json").write_text(json.dumps(trace, indent=2, default=str), encoding='utf-8')
    return trace

@app.get('/api/agents/{case_id}')
def agents_api(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    trace = create_agent_execution_trace(ctx)
    return trace

@app.post('/api/agents/{case_id}/run')
def run_agents_api(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    new_status = recompute_case_status(ctx)
    if new_status != ctx['decision']:
        ctx = customer_context(case_id)
    trace = create_agent_execution_trace(ctx)
    audit_dir = BASE/'outputs'/'audit_logs'
    audit_dir.mkdir(parents=True, exist_ok=True)
    with (audit_dir/'agent_runs.log').open('a', encoding='utf-8') as f:
        f.write(f"{trace['generated_at']} | {user.get('username')} | {trace['run_id']} | {case_id} | {trace['decision']} | {trace['agent_count']} agents\n")
    return trace


@app.post('/staff/run-verification')
def run_verification_workflow(request: Request, case_id: str=Form('CASE001')):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    if ctx:
        recompute_case_status(ctx)
        ctx = customer_context(case_id) or ctx
        trace = create_agent_execution_trace(ctx)
        audit_dir = BASE/'outputs'/'audit_logs'
        audit_dir.mkdir(parents=True, exist_ok=True)
        with (audit_dir/'verification_runs.log').open('a', encoding='utf-8') as f:
            f.write(f"{datetime.now().isoformat()} | {user['username']} | FULL_VERIFICATION | {ctx['cust']['case_id']} | {trace.get('decision')} | {trace.get('agent_count')} agents\n")
        return redirect(request, f"/staff/case/{ctx['cust']['case_id']}?saved=1")
    return redirect(request, '/staff/dashboard')

@app.get('/staff/risk')
def risk(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    df=enrich_rows(queue_df().head(120).to_dict('records'))
    return templates.TemplateResponse(request, 'risk_guardrail.html', {'request':request,'user':user,'active':'risk','rows':df,'m':metrics(),'insights':ops_insights()})

@app.get('/staff/human-review')
def human_review(request: Request):
    return staff_queue(request, status='Manual Review Required')

def notification_log_path():
    p = BASE/'outputs'/'audit_logs'/'notification_email_log.csv'
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def notification_records(limit=20):
    p = notification_log_path()
    if p.exists():
        df = pd.read_csv(p)
        if not df.empty:
            return df.tail(limit).iloc[::-1].to_dict('records')
    return [
        {'created_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'case_id':'CASE1001','recipient':'Customer','recipient_email':'customer@example.com','subject':'KYC application update','message':'Your application has been received and is awaiting evidence upload.','delivery_status':'Sent'},
        {'created_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'case_id':'CASE1001','recipient':'Staff','recipient_email':'kyc.operations@example.com','subject':'New application assigned','message':'A new customer onboarding case is ready for review.','delivery_status':'Sent'},
    ]

def append_notification_record(case_id, recipient, recipient_email, subject, message, status='Sent'):
    row = {'created_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'case_id':case_id, 'recipient':recipient, 'recipient_email':recipient_email, 'subject':subject, 'message':message, 'delivery_status':status}
    p = notification_log_path()
    df = pd.read_csv(p) if p.exists() else pd.DataFrame()
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True) if not df.empty else pd.DataFrame([row])
    df.to_csv(p, index=False)
    return row

@app.get('/staff/notifications')
def notifications(request: Request, sent: str=''):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    examples=[
        {'to':'Customer','title':'KYC approved','body':'Your KYC verification has been approved. You may continue with onboarding.'},
        {'to':'Customer','title':'Document re-upload required','body':'Please upload the requested corrected document from your secure portal.'},
        {'to':'Staff','title':'Manual review assigned','body':'A case requires staff review and final action.'},
        {'to':'Customer','title':'KYC status update','body':'Your application status has been updated. Please log in to view the latest action.'},
    ]
    return templates.TemplateResponse(request, 'notification_email_center.html', {'request':request,'user':user,'active':'notifications','examples':examples,'records':notification_records(),'sent':bool(sent)})

@app.post('/staff/notifications/send')
def send_notification(request: Request, case_id: str=Form(''), recipient: str=Form('Customer'), recipient_email: str=Form(''), subject: str=Form(...), message: str=Form(...)):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    case_id = clean_value(case_id, 'N/A')
    append_notification_record(case_id, recipient, clean_value(recipient_email, 'recorded-recipient'), subject, message, 'Sent')
    with (BASE/'outputs'/'audit_logs'/'staff_actions.log').open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now().isoformat()} | {user['username']} | {case_id} | Notification sent | {recipient} | {subject}\n")
    return redirect(request, '/staff/notifications?sent=1')

@app.get('/staff/system-health')
def system_health(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    health = integration_health_summary()
    return templates.TemplateResponse(request, 'system_health.html', {'request':request,'user':user,'active':'system_health','health':health,'m':metrics()})

@app.get('/api/system-health')
def api_system_health(request: Request):
    user=get_user(request) or {'role':'guest'}
    if user.get('role') != 'staff':
        return JSONResponse({'error':'unauthorized'}, 401)
    return {'items': integration_health_summary(), 'summary': system_health_text()}

@app.get('/staff/audit')
def audit(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    hist=load_data()['history'].head(50).to_dict('records')
    return templates.TemplateResponse(request, 'audit_evidence_pack.html', {'request':request,'user':user,'active':'audit','hist':hist})

@app.get('/staff/closure')
def closure(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    rows=queue_df().tail(40).to_dict('records')
    return templates.TemplateResponse(request, 'case_closure_full.html', {'request':request,'user':user,'active':'closure','rows':rows})



@app.get('/staff/onboarding')
def staff_onboarding_alias(request: Request):
    return staff_customer_registration(request)

@app.get('/staff/customer-registration')
def staff_customer_registration(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    return templates.TemplateResponse(request, 'staff_customer_registration.html', {'request':request,'user':user,'active':'customer_registration'})

@app.get('/staff/document-upload-checklist')
def document_upload_checklist(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'document_upload_checklist.html', {'request':request,'user':user,'active':'document_upload','case_id':case_id,'ctx':ctx})

@app.get('/staff/photo-document-preview')
def photo_document_preview(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'photo_document_preview.html', {'request':request,'user':user,'active':'preview','case_id':case_id,'ctx':ctx})

@app.get('/staff/multi-agent-review')
def multi_agent_review_alias(request: Request, case_id: str='CASE001'):
    return agent_command_center(request, case_id)

@app.get('/staff/risk-guardrail-intelligence')
def risk_guardrail_alias(request: Request):
    return risk(request)

@app.get('/staff/human-review-workflow')
def human_review_workflow(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'human_review_workflow.html', {'request':request,'user':user,'active':'human_review','case_id':case_id,'ctx':ctx})

@app.get('/staff/notification-email-center')
def notification_email_center_alias(request: Request):
    return notifications(request)

@app.get('/staff/audit-evidence-pack')
def audit_evidence_pack_alias(request: Request):
    return audit(request)

@app.get('/staff/case-closure')
def case_closure_alias(request: Request):
    return closure(request)

@app.get('/customer/dashboard')
def customer_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_dashboard.html', {'request':request,'user':user,'active':'customer_dashboard',**ctx})


def next_application_identity():
    """Use the reserved onboarding application range first (CUST1001-CUST1015),
    so new applicants are not mixed with the 5000 existing portfolio records."""
    customers = read_csv('customers.csv')
    existing_customers = set(customers.get('customer_id', pd.Series(dtype=str)).astype(str).str.upper()) if not customers.empty else set()
    existing_cases = set(customers.get('case_id', pd.Series(dtype=str)).astype(str).str.upper()) if not customers.empty else set()
    for n in range(1001, 1016):
        cid = f'CUST{n:04d}'
        case = f'CASE{n:04d}'
        if cid not in existing_customers and case not in existing_cases:
            return cid, case, f'cust{n:04d}'
    nums=[]
    for cid in existing_customers:
        m=re.search(r'(\d+)$', cid)
        if m:
            nums.append(int(m.group(1)))
    n=(max(nums) if nums else 5000) + 1
    while f'CUST{n:04d}' in existing_customers or f'CASE{n:04d}' in existing_cases:
        n += 1
    return f'CUST{n:04d}', f'CASE{n:04d}', f'cust{n:04d}'

def sample_evidence_packages():
    root = BASE / 'uploads' / 'sample_evidence_packages'
    manifest = read_csv('sample_customer_manifest.csv')
    rows=[]
    for i, d in enumerate(sorted(root.glob('PACKAGE*')), start=1):
        if not d.is_dir():
            continue
        name='Evidence Package'
        scenario='Prepared evidence'
        if not manifest.empty and 'package_id' in manifest.columns:
            hit=manifest[manifest['package_id'].astype(str).str.upper().eq(d.name.upper())]
            if not hit.empty:
                name=clean_value(hit.iloc[0].get('name'), name)
                scenario=clean_value(hit.iloc[0].get('scenario'), scenario)
        rows.append({'package_id':d.name,'label':f'Evidence Package {i:02d}','identity_name':name,'scenario':scenario,'file_count':len([x for x in d.iterdir() if x.is_file()])})
    return rows

@app.get('/customer/register')
def register_page(request: Request):
    # Public-only registration page: no dashboard/sidebar is shown before application creation.
    return templates.TemplateResponse(request, 'register.html', {'request':request,'user':None,'active':'register'})

@app.post('/customer/register')
def register_customer(request: Request, full_name: str=Form(...), email: str=Form(...), mobile: str=Form(...), dob: str=Form(...), gender: str=Form(...), address: str=Form(...), city: str=Form(...), state: str=Form(...), occupation: str=Form(...), income_range: str=Form(...), password: str=Form(...), confirm_password: str=Form(...), policy: str=Form('Standard Onboarding')):
    if password != confirm_password or len(password) < 8:
        return templates.TemplateResponse(request, 'register.html', {'request':request,'user':None,'active':'register','error':'Password must be at least 8 characters and both password fields must match.'})
    customers=read_csv('customers.csv')
    if not customers.empty and 'email' in customers.columns and email.strip().lower() in customers['email'].astype(str).str.lower().values:
        return templates.TemplateResponse(request, 'register.html', {'request':request,'user':None,'active':'register','error':'An application already exists for this email address.'})
    cid, case, username = next_application_identity()
    status_map={}
    new={'case_id':case,'customer_id':cid,'login_username':username,'login_password_hash':password_hash(password),'full_name':full_name,'dob':dob,'gender':gender,'email':email,'mobile':mobile,'address':address,'city':city,'state':state,'country':'India','nationality':'Indian','occupation':occupation,'income_range':income_range,'customer_type':'Retail','application_channel':'Customer Portal','application_date':datetime.now().date().isoformat(),'case_status':'More Documents Required','assigned_queue':'Onboarding Queue','sla_hours':72,'synthetic_risk_profile':'Low','profile_image_path':'uploads/customer_uploaded_documents/.gitkeep'}
    customers=pd.concat([customers, pd.DataFrame([new])], ignore_index=True)
    customers.to_csv(BASE/'data'/'customers.csv', index=False)
    record_access_detail(cid, case, username, email)

    # Screen the new applicant against the global sanctions/PEP/fraud/adverse-media watchlist
    hits = screen_against_global_watchlist(full_name, dob)
    apply_screening_results(case, cid, hits)
    if hits['sanctions']:
        customers = read_csv('customers.csv')
        mask = customers['case_id'].astype(str).str.upper() == case.upper()
        customers.loc[mask, 'case_status'] = 'Rejected / Escalated'
        if 'synthetic_risk_profile' in customers.columns:
            customers.loc[mask, 'synthetic_risk_profile'] = 'Critical'
        customers.to_csv(BASE/'data'/'customers.csv', index=False)

    request.session['user']={'role':'customer','username':username,'customer_id':cid,'case_id':case,'name':full_name}
    request.session['last_registered']={'case_id':case,'customer_id':cid}
    return redirect(request, '/customer/dashboard')

@app.get('/customer/upload')
def upload_page(request: Request):
    user=get_user(request) or {'role':'guest','name':'New Applicant'}
    last=request.session.get('last_registered')
    return templates.TemplateResponse(request, 'upload.html', {'request':request,'user':user,'active':'upload','last':last,'saved':None,'packages':sample_evidence_packages()})

@app.post('/customer/upload')
async def upload_docs(request: Request, files: list[UploadFile]=File(default=[])):
    last=request.session.get('last_registered') or {'customer_id':'NEW'}
    cid=last.get('customer_id','NEW')
    case_id=last.get('case_id','')
    out=BASE/'uploads'/'customer_uploaded_documents'/cid
    out.mkdir(parents=True, exist_ok=True)
    saved=[]
    extraction_summary=[]
    for f in files:
        if f.filename:
            dest=out/f.filename
            with dest.open('wb') as w: shutil.copyfileobj(f.file,w)
            saved.append(f.filename)
            if case_id:
                rel_path = str(dest.relative_to(BASE)).replace('\\','/')
                ocr_text = _ocr_text_from_file(dest)
                doc_type = classify_document_type(f.filename, ocr_text)
                size_kb = max(1, dest.stat().st_size // 1024)
                file_type = (dest.suffix.lstrip('.').upper() or 'FILE')
                cust_for_upload = get_customer(case_id) or {}
                if is_photo_or_selfie(f.filename, doc_type):
                    low = (str(f.filename) + ' ' + str(doc_type)).lower()
                    if 'selfie' in low:
                        upsert_selfie_record(case_id, cid, rel_path)
                        photo_doc_type = 'Selfie / Photo'
                    else:
                        update_customer_profile_image(case_id, rel_path)
                        photo_doc_type = 'Customer Photo'
                    append_kyc_document_record(case_id, cid, photo_doc_type, f.filename, rel_path, {'name':'','dob':'','address':'','id_number':''}, size_kb, file_type)
                    extraction_summary.append({'file_name': f.filename, 'document_type': photo_doc_type, 'extracted_name': 'Photo evidence captured', 'extracted_dob': '', 'extracted_address': ''})
                    continue
                extracted = extract_document_fields(dest, ocr_text)
                extracted = enrich_extraction_from_filename(extracted, f.filename)
                # Do not copy registration fields into extracted document fields. That hides real
                # Arjun-vs-Ramesh style mismatches. Missing OCR remains "Needs review" and is
                # handled by the review/status engine.
                append_kyc_document_record(case_id, cid, doc_type, f.filename, rel_path, extracted, size_kb, file_type)
                extraction_summary.append({
                    'file_name': f.filename, 'document_type': doc_type,
                    'extracted_name': clean_value(extracted.get('name'), 'Needs review'),
                    'extracted_dob': clean_value(extracted.get('dob'), 'Needs review'),
                    'extracted_address': clean_value(extracted.get('address'), 'Needs review'),
                })

    cross_check_issues = []
    new_status = None
    if case_id:
        sync_document_extractions_for_case(case_id)
        ctx = customer_context(case_id)
        if ctx:
            new_status = recompute_case_status(ctx)
            ctx = customer_context(case_id) or ctx
            cross_check_issues = ctx.get('cross_check_issues', [])

    return templates.TemplateResponse(request, 'upload.html', {
        'request':request, 'user':get_user(request) or {'role':'guest','name':'New Applicant'},
        'active':'upload', 'last':last, 'saved':saved,
        'extraction_summary':extraction_summary, 'cross_check_issues':cross_check_issues,
        'new_status':new_status, 'packages':sample_evidence_packages(),
    })



@app.post('/customer/load-evidence-package')
def load_evidence_package(request: Request, package_id: str=Form(...)):
    user=require_login(request)
    if not user or user.get('role')!='customer':
        return redirect(request, '/')
    cid=clean_value(user.get('customer_id'))
    case_id=clean_value(user.get('case_id'))
    pkg_id=clean_value(package_id).upper()
    pkg_dir=BASE/'uploads'/'sample_evidence_packages'/pkg_id
    if not cid or not case_id or not pkg_dir.exists() or not pkg_dir.is_dir():
        return templates.TemplateResponse(request, 'upload.html', {
            'request':request,'user':user,'active':'upload','last':{'customer_id':cid,'case_id':case_id},
            'saved':None,'packages':sample_evidence_packages(),'error':'Selected evidence package is not available.'
        })
    out=BASE/'uploads'/'customer_uploaded_documents'/cid
    out.mkdir(parents=True, exist_ok=True)
    saved=[]; extraction_summary=[]
    for src in sorted(pkg_dir.iterdir()):
        if not src.is_file():
            continue
        dest=out/src.name
        shutil.copy2(src, dest)
        saved.append(src.name)
        rel_path=str(dest.relative_to(BASE)).replace('\\','/')
        ocr_text=_ocr_text_from_file(dest)
        doc_type=classify_document_type(src.name, ocr_text)
        size_kb=max(1, dest.stat().st_size//1024)
        file_type=dest.suffix.lstrip('.').upper() or 'FILE'
        if is_photo_or_selfie(src.name, doc_type):
            low = (str(src.name) + ' ' + str(doc_type)).lower()
            if 'selfie' in low:
                upsert_selfie_record(case_id, cid, rel_path)
                photo_doc_type = 'Selfie / Photo'
            else:
                update_customer_profile_image(case_id, rel_path)
                photo_doc_type = 'Customer Photo'
            append_kyc_document_record(case_id, cid, photo_doc_type, src.name, rel_path, {'name':'','dob':'','address':'','id_number':'','_extraction_method':'photo_evidence'}, size_kb, file_type)
            extraction_summary.append({'file_name':src.name,'document_type':photo_doc_type,'extracted_name':'Photo evidence captured','extracted_dob':'','extracted_address':''})
            continue
        extracted=extract_document_fields(dest, ocr_text)
        extracted=enrich_extraction_from_filename(extracted, src.name)
        source_type=clean_value(extracted.get('_source_document_type'))
        if source_type and source_type not in ('Other Document','Selfie / Photo'):
            doc_type=source_type
        append_kyc_document_record(case_id, cid, doc_type, src.name, rel_path, extracted, size_kb, file_type)
        extraction_summary.append({'file_name':src.name,'document_type':doc_type,'extracted_name':clean_value(extracted.get('name'),'Needs review'),'extracted_dob':clean_value(extracted.get('dob'),'Needs review'),'extracted_address':clean_value(extracted.get('address'),'Needs review')})
    sync_document_extractions_for_case(case_id)
    ctx=customer_context(case_id)
    new_status=recompute_case_status(ctx) if ctx else None
    ctx=customer_context(case_id) or ctx
    cross_check_issues=ctx.get('cross_check_issues', []) if ctx else []
    return templates.TemplateResponse(request, 'upload.html', {
        'request':request,'user':user,'active':'upload','last':{'customer_id':cid,'case_id':case_id},
        'saved':saved,'extraction_summary':extraction_summary,'cross_check_issues':cross_check_issues,
        'new_status':new_status,'packages':sample_evidence_packages()
    })

@app.get('/customer/profile')
def customer_profile_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_profile_page.html', {'request':request,'user':user,'active':'customer_profile',**ctx})

@app.get('/customer/photo-selfie')
def customer_photo_selfie(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_photo_selfie.html', {'request':request,'user':user,'active':'customer_photo',**ctx})

@app.get('/customer/status')
def customer_status_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    stages=['Application Submitted','Documents Uploaded','AI Agent Validation','Compliance Screening','Human Review / Decision','Closure']
    return templates.TemplateResponse(request, 'customer_status_page.html', {'request':request,'user':user,'active':'customer_status','stages':stages,**ctx})

@app.get('/customer/checklist')
def customer_checklist_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    required=['PAN Card','Aadhaar Card','Bank Statement','Salary Slip','Utility Bill','Passport','Voter ID']
    return templates.TemplateResponse(request, 'customer_checklist_page.html', {'request':request,'user':user,'active':'customer_checklist','required':required,**ctx})

@app.get('/customer/request-status')
def customer_request_status(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_request_status.html', {'request':request,'user':user,'active':'customer_request',**ctx})

@app.get('/customer/notifications')
def customer_notifications(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    notes=[
        {'title':'Application received','body':'Your KYC application has been received and assigned a case ID.'},
        {'title':'AI verification completed','body':'Document intelligence and identity verification checks have been completed.'},
        {'title':'Next action','body':f"Current status: {ctx['decision'] if ctx else 'Pending'}."},
    ]
    return templates.TemplateResponse(request, 'customer_notifications.html', {'request':request,'user':user,'active':'customer_notifications','notes':notes,**ctx})

@app.get('/customer/final-decision')
def customer_final_decision(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return redirect(request, '/')
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_final_decision.html', {'request':request,'user':user,'active':'customer_final',**ctx})


@app.get('/staff/orchestrator')
def orchestrator_console(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    workflow=[
        'Customer KYC Portal','Multimodal Upload Layer','OCR + Document Intelligence Layer','Data Protection Layer','Master Orchestrator Agent','Document Intelligence Agent','Identity Verification Agent','Compliance RAG Agent','AML & Sanctions Screening Agent','Adverse Media Intelligence Agent','Financial Profiling Agent','Fraud Intelligence Agent','Risk Intelligence Agent','Decision Reasoning Agent','Notification & Email Agent','Human Review Agent','Audit & Governance Agent','Shared Agent Memory Bus','RAG Knowledge Retrieval + Vector Database','Explainable Decision Engine','Human Review Workflow','Email Notification + Audit Trail','Final KYC Evidence Pack'
    ]
    return templates.TemplateResponse(request, 'orchestrator.html', {'request':request,'user':user,'active':'orchestrator','workflow':workflow,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/staff/memory-rag')
def memory_rag_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    policy_path=BASE/'data'/'kyc_policy_knowledge.txt'
    policy=policy_path.read_text(encoding='utf-8', errors='ignore') if policy_path.exists() else 'KYC policy knowledge base not found.'
    return templates.TemplateResponse(request, 'memory_rag.html', {'request':request,'user':user,'active':'memory','policy':policy,'m':metrics()})

@app.get('/staff/original-workflow')
def original_workflow_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    workflow=[
        'Customer onboarding request','Multimodal document upload layer','OCR + Document Intelligence','Data protection','Master Orchestrator Agent','Document Intelligence Agent','Identity Verification Agent','Compliance RAG Agent','AML & Sanctions Screening Agent','Adverse Media Intelligence Agent','Financial Profiling Agent','Fraud Intelligence Agent','Risk Intelligence Agent','Decision Reasoning Agent','Notification & Email Agent','Human Review Agent','Audit & Governance Agent','Shared Agent Memory Bus','RAG Knowledge Retrieval + Vector Database','Explainable Decision Engine','Human Review Workflow','Email Notification + Audit Trail','Final KYC Evidence Pack'
    ]
    return templates.TemplateResponse(request, 'original_workflow.html', {'request':request,'user':user,'active':'workflow','workflow':workflow,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/api/pipeline/{case_id}')
def pipeline_api(request: Request, case_id: str):
    user=require_login(request)
    if not user: return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    return {'case_id':ctx['cust']['case_id'],'workflow':['intake','document_intelligence','data_protection','identity_verification','compliance_rag','aml_sanctions','adverse_media','financial_profile','fraud_intelligence','risk_intelligence','decision_reasoning','human_review','notification_audit','audit_governance'],'decision':ctx['decision'],'agents':agent_run_for_case(ctx)}


@app.get('/staff/case/{case_id}/evidence-pack')
def download_case_evidence_pack(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id)
    if not ctx:
        return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'Evidence pack could not be generated because the case was not found.'})
    return redirect(request, f"/staff/case/{case_id}/evidence-pack.pdf")

@app.get('/staff/case/{case_id}/evidence-pack.pdf')
def download_case_evidence_pack_pdf(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id)
    if not ctx:
        return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'Evidence pack could not be generated because the case was not found.'})
    pdf_bytes = build_evidence_pack_pdf(ctx)
    filename = f"TrustShield_KYC_Evidence_Pack_{ctx['cust'].get('case_id', case_id)}.pdf"
    return Response(pdf_bytes, media_type='application/pdf', headers={'Content-Disposition': f'attachment; filename="{filename}"'})

@app.get('/staff/case/{case_id}/evidence-pack.txt')
def download_case_evidence_pack_txt(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return redirect(request, '/')
    ctx=customer_context(case_id)
    if not ctx:
        return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'Evidence pack could not be generated because the case was not found.'})
    content = build_evidence_pack_text(ctx)
    filename = f"TrustShield_KYC_Evidence_Pack_{ctx['cust'].get('case_id', case_id)}.txt"
    return Response(content, media_type='text/plain', headers={'Content-Disposition': f'attachment; filename="{filename}"'})

@app.get('/media/{path:path}')
def media(path:str):
    p=BASE/path
    if p.exists(): return FileResponse(p)
    return JSONResponse({'error':'not found'},404)

def portfolio_screening_counts():
    d=load_data()
    s=d['sanctions']; p=d['pep']; f=d['fraud']; a=d['adverse']
    out={'sanctions':0,'high_risk_country':0,'pep':0,'adverse':0,'fraud':0}
    if not s.empty:
        if 'sanctions_match' in s: out['sanctions']=int(pd.to_numeric(s['sanctions_match'],errors='coerce').fillna(0).eq(1).sum())
        if 'high_risk_country' in s: out['high_risk_country']=int(pd.to_numeric(s['high_risk_country'],errors='coerce').fillna(0).eq(1).sum())
    if not p.empty and 'pep_match' in p:
        out['pep']=int(pd.to_numeric(p['pep_match'],errors='coerce').fillna(0).eq(1).sum())
    if not a.empty and 'adverse_media_match' in a:
        out['adverse']=int(pd.to_numeric(a['adverse_media_match'],errors='coerce').fillna(0).eq(1).sum())
    if not f.empty:
        flags=[c for c in ['duplicate_mobile','duplicate_pan','duplicate_bank_account','repeated_kyc_attempt','synthetic_identity_signal'] if c in f]
        if flags:
            out['fraud']=int((pd.to_numeric(f[flags].stack(),errors='coerce').fillna(0)==1).sum())
    return out

def fallback_answer(user, q):
    ql = q.lower().strip()
    d = load_data(); m = metrics()
    role = (user or {}).get('role','guest')

    # ---- Universal small talk ----
    greetings = ('hi','hello','hey','hiya','namaste','good morning','good afternoon','good evening','yo')
    if any(ql==g or ql.startswith(g+' ') or ql.startswith(g+',') or ql.startswith(g+'!') for g in greetings):
        if role=='customer':
            ctx=customer_context(user.get('customer_id'))
            name=ctx['cust']['full_name'].split(' ')[0] if ctx else 'there'
            return f"Hello {name}! I'm your TrustShield assistant. I can check your KYC status, list required documents, explain why a case is in review, and tell you what to do next. What would you like to know?"
        if role=='staff':
            return "Hello! I'm your TrustShield operations assistant. Ask me about case metrics, case queues, a specific Case/Customer ID, AML/PEP/fraud screening, SLA breaches or case guidance."
        return "Hello! Sign in to get personalized KYC help, or ask a general question about TrustShield KYC."

    if any(t in ql for t in ('thank you','thanks','thx','appreciate it','great job','awesome')):
        return "You're welcome! Let me know if there's anything else about your KYC case or the platform I can help with."

    if ql in ('?','help','menu','what can you do','what can you do?','options','commands'):
        if role=='customer':
            return ("I can help with:\n"
                    "• My KYC status — \"What is my KYC status?\"\n"
                    "• Required documents — \"What documents do I need?\"\n"
                    "• Review reasons — \"Why is my case in review?\"\n"
                    "• Screening results — \"Any sanctions or PEP flags on my case?\"\n"
                    "• Timelines — \"How long will my KYC take?\"\n"
                    "• Support — \"How do I contact support?\"")
        return ("I can help staff with:\n"
                "• Case overview — \"Case summary\" / \"How many customers?\"\n"
                "• Case lookup — \"Status of CASE0007\" or \"Show CUST0012\"\n"
                "• Queues — \"How many in manual review?\" / \"Document remediation count\"\n"
                "• KYC guidances — \"What is the current review guidance?\"\n"
                "• Risk & screening — \"High risk cases\", \"Sanctions hits\", \"PEP matches\", \"Fraud signals\"\n"
                "• SLA — \"SLA breaches today\"\n"
                "• AI agents — \"How many AI agents run per case?\"")

    # ---- Case / Customer ID lookup (works for both roles, scoped) ----
    id_match = re.search(r'\b(CASE\s?-?\s?0*\d+|CUST\s?-?\s?0*\d+)\b', q, re.I)
    if id_match:
        raw=re.sub(r'\s|-', '', id_match.group(1)).upper()
        idm=re.match(r'(CASE|CUST)0*(\d+)', raw)
        ctx=None
        if idm:
            prefix,num=idm.groups()
            for cand in (f"{prefix}{num.zfill(3)}", f"{prefix}{num.zfill(4)}", f"{prefix}{num}"):
                ctx=customer_context(cand)
                if ctx:
                    raw=cand
                    break
        if role=='customer':
            own_ctx=customer_context(user.get('customer_id'))
            own_case=str(own_ctx['cust']['case_id']).upper() if own_ctx else ''
            own_cust=str(own_ctx['cust']['customer_id']).upper() if own_ctx else ''
            if raw not in (own_case, own_cust):
                return "I can only share details about your own case. Ask me \"What is my KYC status?\" for your case information."
            ctx=own_ctx
        if not ctx:
            return f"I couldn't find a case or customer matching '{raw}'. Double-check the ID and try again."
        cust=ctx['cust']; sc=customer_screening_summary(cust['customer_id'])
        flags='None' if not sc['notes'] else '; '.join(sc['notes'])
        return (f"{cust['full_name']} — Case {cust['case_id']} ({cust['customer_id']})\n"
                f"Status: {ctx['decision']} | Risk: {cust.get('synthetic_risk_profile','N/A')} | Queue: {cust.get('assigned_queue','N/A')} | SLA: {cust.get('sla_hours','N/A')}h\n"
                f"Discrepancies: {ctx['discrepancy']} | Screening flags: {flags}")

    # ---- Customer-facing intents ----
    if role=='customer':
        ctx=customer_context(user.get('customer_id'))
        if not ctx: return 'I could not find your customer case. Please contact support.'
        cust=ctx['cust']; sc=customer_screening_summary(cust['customer_id'])

        if any(k in ql for k in ('status','kyc','decision','progress','approved','where do i stand','application')):
            extra = '' if ctx['decision']=='Approved' else f" It is currently assigned to {cust.get('assigned_queue','our operations team')} with an SLA of {cust.get('sla_hours','N/A')} hours."
            return f"Your KYC status is '{ctx['decision']}' for case {cust['case_id']}.{extra}"

        if any(k in ql for k in ('document','upload','checklist','missing','pending','re-upload','reupload')):
            if ctx['issues']:
                return ("I found the following document issue(s) on your case:\n- " + "\n- ".join(ctx['issues']) +
                        "\nPlease go to 'Upload Documents' to re-submit a clear, valid copy.")
            return f"All {len(ctx['docs'])} document records on file look fine. Required documents are PAN, Aadhaar, bank statement, salary slip and utility bill — check the 'Document Checklist' page for the full list."

        if any(k in ql for k in ('why','reject','reason','review','escalat','hold')):
            if ctx['discrepancy']==0:
                return "Your case has no open discrepancies. If it still shows 'Manual Review Required', our team is doing a final quality check before approval."
            return (f"Your case has {ctx['discrepancy']} discrepancy/discrepancies that triggered manual review:\n- " + "\n- ".join(ctx['issues']) +
                    "\nResolving these (usually by re-uploading a clearer document) can speed up your decision.")

        if any(k in ql for k in ('sanction','pep','screen','aml','adverse','watchlist')):
            if not sc['notes']:
                return "Good news — your case has no sanctions, PEP or adverse-media flags. Screening is clear."
            return "Your case has the following screening note(s): " + "; ".join(sc['notes']) + ". Our compliance team will review this as part of your case."

        if any(k in ql for k in ('risk',)):
            return f"Your current risk profile is '{cust.get('synthetic_risk_profile','Low')}'. This is based on document quality, identity match, screening results and your declared profile."

        if any(k in ql for k in ('sla','how long','when will','time','eta','duration')):
            return f"Your case is assigned to {cust.get('assigned_queue','our operations team')} with a target SLA of {cust.get('sla_hours','N/A')} hours from submission. You'll be notified as soon as a decision is made."

        if any(k in ql for k in ('contact','support','help','phone','email','reach','agent')):
            return "For further help, use the 'Notifications' page for updates on your case, or contact TrustShield support at support@trustshield-kyc.example. Your reference is case " + str(cust['case_id']) + "."

        return (f"I can help with your KYC status, required documents, the reason for review, screening results, timelines and support. "
                f"Your case ID is {cust['case_id']} and current status is '{ctx['decision']}'.")

    # ---- Staff-facing intents ----
    insights = ops_insights()
    if any(k in ql for k in ('system health','health status','integration status','gemini status','platform status','service status','pdf service','email service','agent workflow')):
        return system_health_text()
    if any(k in ql for k in ('portfolio','total','how many customer','customer count','overview','summary')):
        return (f"Case summary: {m.get('total',0)} customers — {m.get('approved',0)} approved, "
                f"{m.get('review',0)} in manual review, {m.get('docs',0)} awaiting documents, "
                f"{m.get('rejected',0)} rejected. Approval rate ~{insights.get('approval_rate',0)}%.")

    if any(k in ql for k in ('rule','approve','policy','criteria','threshold')):
        return ('KYC outcomes are based on submitted profile details, document evidence, identity confidence, screening results and authorized staff review controls.')

    if any(k in ql for k in ('manual review','review queue','in review')):
        return f"There are {m.get('review',0)} cases in Manual Review Required. Open Case Workbench and filter by that status to start working through them."

    if any(k in ql for k in ('document remediation','more document','missing document','re-upload queue')):
        return f"There are {m.get('docs',0)} cases waiting on 'More Documents Required'. These need a customer re-upload before they can proceed."

    if 'reject' in ql or 'escalat' in ql:
        return f"There are {m.get('rejected',0)} rejected/escalated cases out of {m.get('total',0)} total."

    if any(k in ql for k in ('sla','breach','overdue','late')):
        return f"{insights.get('breach',0)} case(s) currently have an SLA of 24 hours or less remaining — prioritize these in the Case Workbench."

    if 'risk' in ql:
        return f"There are {m.get('high',0)} High/Critical risk cases out of {m.get('total',0)}. Open Risk Intelligence to review them with explainable scoring."

    if any(k in ql for k in ('sanction','pep','aml','adverse','fraud','watchlist','screen')):
        sc=portfolio_screening_counts()
        return (f"Screening snapshot across the portfolio: {sc['sanctions']} sanctions match(es), "
                f"{sc['pep']} PEP match(es), {sc['adverse']} adverse-media match(es), "
                f"{sc['high_risk_country']} high-risk-country flag(s), and {sc['fraud']} fraud signal(s). "
                f"Open AML & Sanctions Screening or Adverse Media agents on a case for details.")

    if 'agent' in ql or 'ai' in ql or 'orchestrat' in ql:
        return (f"TrustShield runs {len(AGENT_CATALOG)} specialized AI agents per case — document intelligence, identity "
                f"verification, data protection, compliance review, AML/sanctions, adverse media, financial profiling, fraud "
                f"intelligence, risk intelligence, decision reasoning, human review and notification/audit. Run them from "
                f"any case profile or the AI Agents Command Center.")

    if any(k in ql for k in ('channel','source','application channel')):
        if insights.get('channels'):
            top=', '.join(f"{c['name']} ({c['count']})" for c in insights['channels'][:3])
            return f"Top application channels: {top}."
        return "Channel breakdown is not available for this dataset."

    if any(k in ql for k in ('state','location','region','geograph')):
        if insights.get('states'):
            top=', '.join(f"{s['name']} ({s['count']})" for s in insights['states'][:3])
            return f"Top customer states: {top}."
        return "State/region breakdown is not available for this dataset."

    return ('I can help with AI agent orchestration, case/customer lookup (try "status of CASE0007"), '
            'case queues, case guidance, risk and screening summaries, SLA breaches, and notifications/audit. '
            'Type "help" to see everything I can do.')

@app.post('/api/chat')
async def chat_api(request: Request):
    user=get_user(request) or {'role':'guest'}
    try:
        data=await request.json()
    except Exception:
        data={}
    question=str(data.get('question','')).strip()[:1000]
    if not question:
        return {'answer':'Please enter a KYC question. I can help with case status, queue summary, document issues, risk controls and next actions.'}
    answer=None
    if gemini_key_configured():
        try:
            from google import genai
            client=genai.Client(api_key=API_KEY)
            role='customer' if user.get('role')=='customer' else 'staff'
            facts = fallback_answer(user, question)
            ctx=(
                f"You are TrustShield KYC Assistant for a {role} user of an enterprise KYC platform. "
                "Be concise, professional and action-oriented (max 4 sentences). "
                "Do not expose other customers' data or staff-only portfolio details to customers. "
                "Use the following platform facts as ground truth and do not contradict them: "
                f"{facts}"
            )
            resp=client.models.generate_content(model=MODEL, contents=ctx+'\nQuestion: '+question)
            text=getattr(resp,'text',None)
            answer = text.strip() if text and text.strip() else None
        except Exception:
            answer=None
    return {'answer': answer or fallback_answer(user,question), 'mode': 'gemini' if answer else 'local'}

@app.get('/api/chat/health')
def chat_health(request: Request):
    user=get_user(request) or {'role':'guest'}
    return {'status':'ok','role':user.get('role'),'gemini_configured':bool(API_KEY),'model':MODEL}
